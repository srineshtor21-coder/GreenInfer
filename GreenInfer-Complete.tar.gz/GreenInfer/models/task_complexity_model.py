"""
Task Complexity Analyzer Model
Classifies query complexity and accuracy requirements for green routing decisions
"""

import torch
import torch.nn as nn
from transformers import DistilBertTokenizer, DistilBertModel
from torch.utils.data import Dataset, DataLoader
import numpy as np
import json
from typing import Dict, Tuple
import re

class TaskComplexityDataset(Dataset):
    """Dataset for training task complexity classifier"""
    
    def __init__(self, texts, complexity_scores, accuracy_requirements, tokenizer, max_length=128):
        self.texts = texts
        self.complexity_scores = complexity_scores
        self.accuracy_requirements = accuracy_requirements
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        text = self.texts[idx]
        encoding = self.tokenizer(
            text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'complexity_score': torch.tensor(self.complexity_scores[idx], dtype=torch.float),
            'accuracy_requirement': torch.tensor(self.accuracy_requirements[idx], dtype=torch.long)
        }


class TaskComplexityModel(nn.Module):
    """
    Multi-task model that predicts:
    1. Complexity score (0-1 regression)
    2. Accuracy requirement (low/medium/high classification)
    """
    
    def __init__(self, pretrained_model='distilbert-base-uncased', dropout=0.3):
        super(TaskComplexityModel, self).__init__()
        
        # Base model
        self.bert = DistilBertModel.from_pretrained(pretrained_model)
        hidden_size = self.bert.config.hidden_size
        
        # Freeze some layers for efficiency
        for param in self.bert.embeddings.parameters():
            param.requires_grad = False
        
        # Complexity regression head
        self.complexity_head = nn.Sequential(
            nn.Linear(hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 1),
            nn.Sigmoid()  # Output between 0 and 1
        )
        
        # Accuracy requirement classification head (3 classes: low, medium, high)
        self.accuracy_head = nn.Sequential(
            nn.Linear(hidden_size, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 3)  # 3 classes
        )
    
    def forward(self, input_ids, attention_mask):
        # Get BERT outputs
        outputs = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0]  # CLS token
        
        # Predict complexity score
        complexity = self.complexity_head(pooled_output)
        
        # Predict accuracy requirement
        accuracy = self.accuracy_head(pooled_output)
        
        return complexity, accuracy


class ComplexityAnalyzer:
    """
    Wrapper class for easy inference
    """
    
    def __init__(self, model_path=None, device='cpu'):
        self.device = device
        self.tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')
        self.model = TaskComplexityModel().to(device)
        
        if model_path:
            self.model.load_state_dict(torch.load(model_path, map_location=device))
        
        self.model.eval()
        
        # Task type keywords for enhanced analysis
        self.task_keywords = {
            'coding': ['code', 'function', 'program', 'debug', 'implement', 'algorithm', 'script'],
            'reasoning': ['why', 'how', 'explain', 'analyze', 'compare', 'evaluate', 'argue'],
            'creative': ['write', 'create', 'story', 'poem', 'essay', 'blog', 'article'],
            'factual': ['what', 'who', 'when', 'where', 'define', 'list', 'name'],
            'mathematical': ['calculate', 'solve', 'equation', 'compute', 'math', 'formula']
        }
    
    def extract_features(self, text: str) -> Dict[str, float]:
        """Extract linguistic features from text"""
        features = {}
        
        # Token count
        tokens = self.tokenizer.tokenize(text)
        features['token_count'] = len(tokens)
        
        # Sentence complexity
        sentences = text.split('.')
        features['sentence_count'] = len(sentences)
        features['avg_sentence_length'] = len(text.split()) / max(len(sentences), 1)
        
        # Question complexity indicators
        features['has_multiple_questions'] = text.count('?') > 1
        features['has_code_blocks'] = '```' in text or 'def ' in text or 'function ' in text
        features['has_requirements'] = any(word in text.lower() for word in ['must', 'should', 'need to', 'require'])
        
        # Task type detection
        text_lower = text.lower()
        for task_type, keywords in self.task_keywords.items():
            features[f'is_{task_type}'] = any(keyword in text_lower for keyword in keywords)
        
        # Vocabulary richness (proxy for complexity)
        words = text.lower().split()
        unique_words = set(words)
        features['vocabulary_richness'] = len(unique_words) / max(len(words), 1)
        
        return features
    
    def analyze(self, text: str) -> Dict[str, any]:
        """
        Analyze task complexity and accuracy requirement
        
        Returns:
            dict with:
                - complexity_score: float (0-1)
                - accuracy_requirement: str (low/medium/high)
                - confidence: float (0-1)
                - features: dict of extracted features
                - task_type: str
        """
        # Extract features
        features = self.extract_features(text)
        
        # Tokenize for model
        encoding = self.tokenizer(
            text,
            max_length=128,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        input_ids = encoding['input_ids'].to(self.device)
        attention_mask = encoding['attention_mask'].to(self.device)
        
        # Get model predictions
        with torch.no_grad():
            complexity, accuracy_logits = self.model(input_ids, attention_mask)
        
        complexity_score = complexity.item()
        accuracy_probs = torch.softmax(accuracy_logits, dim=1)
        accuracy_class = torch.argmax(accuracy_probs, dim=1).item()
        confidence = accuracy_probs[0, accuracy_class].item()
        
        # Map class to label
        accuracy_labels = ['low', 'medium', 'high']
        accuracy_requirement = accuracy_labels[accuracy_class]
        
        # Determine task type
        task_type = 'general'
        for task, keywords in self.task_keywords.items():
            if any(keyword in text.lower() for keyword in keywords):
                task_type = task
                break
        
        # Adjust complexity based on features (ensemble approach)
        feature_complexity = self._calculate_feature_complexity(features)
        final_complexity = 0.7 * complexity_score + 0.3 * feature_complexity
        
        return {
            'complexity_score': float(final_complexity),
            'accuracy_requirement': accuracy_requirement,
            'confidence': float(confidence),
            'features': features,
            'task_type': task_type,
            'token_count': features['token_count']
        }
    
    def _calculate_feature_complexity(self, features: Dict) -> float:
        """Calculate complexity from extracted features"""
        score = 0.0
        
        # Token count contribution
        if features['token_count'] < 20:
            score += 0.1
        elif features['token_count'] < 50:
            score += 0.3
        elif features['token_count'] < 100:
            score += 0.5
        else:
            score += 0.7
        
        # Task type contribution
        if features.get('is_coding', False):
            score += 0.3
        if features.get('is_reasoning', False):
            score += 0.2
        if features.get('is_mathematical', False):
            score += 0.2
        
        # Other indicators
        if features['has_code_blocks']:
            score += 0.2
        if features['has_multiple_questions']:
            score += 0.15
        if features['vocabulary_richness'] > 0.7:
            score += 0.1
        
        return min(score, 1.0)


def train_model(train_loader, val_loader, num_epochs=10, device='cpu'):
    """Training function for the complexity model"""
    model = TaskComplexityModel().to(device)
    
    # Optimizers
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-5, weight_decay=0.01)
    
    # Loss functions
    complexity_criterion = nn.MSELoss()
    accuracy_criterion = nn.CrossEntropyLoss()
    
    best_val_loss = float('inf')
    
    for epoch in range(num_epochs):
        # Training
        model.train()
        train_loss = 0.0
        
        for batch in train_loader:
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            complexity_target = batch['complexity_score'].to(device)
            accuracy_target = batch['accuracy_requirement'].to(device)
            
            optimizer.zero_grad()
            
            complexity_pred, accuracy_pred = model(input_ids, attention_mask)
            
            # Multi-task loss
            loss_complexity = complexity_criterion(complexity_pred.squeeze(), complexity_target)
            loss_accuracy = accuracy_criterion(accuracy_pred, accuracy_target)
            loss = loss_complexity + loss_accuracy
            
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
        
        # Validation
        model.eval()
        val_loss = 0.0
        
        with torch.no_grad():
            for batch in val_loader:
                input_ids = batch['input_ids'].to(device)
                attention_mask = batch['attention_mask'].to(device)
                complexity_target = batch['complexity_score'].to(device)
                accuracy_target = batch['accuracy_requirement'].to(device)
                
                complexity_pred, accuracy_pred = model(input_ids, attention_mask)
                
                loss_complexity = complexity_criterion(complexity_pred.squeeze(), complexity_target)
                loss_accuracy = accuracy_criterion(accuracy_pred, accuracy_target)
                loss = loss_complexity + loss_accuracy
                
                val_loss += loss.item()
        
        avg_train_loss = train_loss / len(train_loader)
        avg_val_loss = val_loss / len(val_loader)
        
        print(f"Epoch {epoch+1}/{num_epochs}")
        print(f"Train Loss: {avg_train_loss:.4f}, Val Loss: {avg_val_loss:.4f}")
        
        # Save best model
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            torch.save(model.state_dict(), 'task_complexity_best.pth')
    
    return model


if __name__ == "__main__":
    # Example usage
    analyzer = ComplexityAnalyzer()
    
    # Test queries
    test_queries = [
        "What is the capital of France?",
        "Write a Python function that implements quicksort algorithm with detailed comments",
        "Explain the philosophical implications of quantum mechanics on determinism",
        "Calculate 2+2"
    ]
    
    for query in test_queries:
        result = analyzer.analyze(query)
        print(f"\nQuery: {query}")
        print(f"Complexity: {result['complexity_score']:.2f}")
        print(f"Accuracy Requirement: {result['accuracy_requirement']}")
        print(f"Task Type: {result['task_type']}")
        print(f"Confidence: {result['confidence']:.2f}")
