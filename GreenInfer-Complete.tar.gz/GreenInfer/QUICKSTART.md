# 🚀 GreenInfer - Quick Start

## Installation (5 minutes)

### 1. Clone Repository
```bash
git clone https://github.com/srineshtor21-coder/GreenInfer.git
cd GreenInfer
```

### 2. Install Dependencies
```bash
# Backend
pip install -r requirements.txt

# Frontend
cd frontend
npm install
cd ..
```

### 3. Run Application

**Terminal 1 - Backend:**
```bash
cd backend
python api.py
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
```

### 4. Open Browser

Navigate to: http://localhost:3000

---

## Upload to GitHub

```bash
git init
git add .
git commit -m "Initial commit: GreenInfer"
git branch -M main
git remote add origin https://github.com/srineshtor21-coder/GreenInfer.git
git push -u origin main
```

---

## Deploy Website

### Option 1: Vercel (Frontend)
```bash
cd frontend
npm run build
vercel deploy
```

### Option 2: Heroku (Backend)
```bash
heroku create greeninfer-api
git push heroku main
```

---

## What's Working Now

✅ Complete orchestration framework  
✅ REST API with 15+ endpoints  
✅ React frontend with analytics  
✅ Energy estimation  
✅ Session management  
✅ Three modes (Eco/Balanced/Performance)  

## What Needs Training (Later)

🔄 Task complexity model - training script ready  
🔄 RL router - code ready, needs data  
🔄 Improved prompt optimizer - current works, can enhance  

---

**That's it! You're ready to showcase GreenInfer! 🌱**
