import React, { useState, useRef, useEffect } from 'react';
import './ChatInterface.css';

function ChatInterface({ sessionId, mode, apiUrl, onQueryComplete }) {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendQuery = async () => {
    if (!inputValue.trim() || !sessionId) return;

    const userMessage = {
      type: 'user',
      content: inputValue,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch(`${apiUrl}/query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: inputValue,
          session_id: sessionId,
          mode: mode
        })
      });

      const data = await response.json();

      if (response.ok) {
        const assistantMessage = {
          type: 'assistant',
          content: data.response,
          timestamp: new Date().toISOString(),
          metadata: {
            model: data.routing_decision.model_name,
            modelSize: data.routing_decision.model_size,
            energy: data.routing_decision.estimated_energy_joules,
            carbon: data.routing_decision.estimated_carbon_grams,
            complexity: data.complexity_analysis.complexity_score,
            accuracyReq: data.routing_decision.accuracy_requirement,
            taskType: data.routing_decision.task_type,
            savings: data.savings,
            optimizationStats: data.optimization_stats,
            alternatives: data.routing_decision.alternatives_considered,
            decisionMethod: data.routing_decision.decision_method
          }
        };

        setMessages(prev => [...prev, assistantMessage]);
        onQueryComplete?.();
      } else {
        const errorMessage = {
          type: 'error',
          content: data.error || 'An error occurred',
          timestamp: new Date().toISOString()
        };
        setMessages(prev => [...prev, errorMessage]);
      }
    } catch (error) {
      console.error('Error sending query:', error);
      const errorMessage = {
        type: 'error',
        content: 'Failed to connect to the server',
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendQuery();
    }
  };

  return (
    <div className="chat-interface">
      <div className="messages-container">
        {messages.length === 0 && (
          <div className="empty-state">
            <h2>🌱 Welcome to Green AI Orchestrator</h2>
            <p>Ask me anything, and I'll route your query to the most energy-efficient AI model!</p>
            <div className="example-prompts">
              <h3>Try these examples:</h3>
              <button onClick={() => setInputValue('What is the capital of France?')} className="example-prompt">
                Simple factual question
              </button>
              <button onClick={() => setInputValue('Write a Python function to implement binary search')} className="example-prompt">
                Coding task
              </button>
              <button onClick={() => setInputValue('Explain quantum computing in simple terms')} className="example-prompt">
                Complex explanation
              </button>
            </div>
          </div>
        )}

        {messages.map((message, index) => (
          <div key={index} className={`message ${message.type}`}>
            <div className="message-content">
              {message.content}
            </div>

            {message.type === 'assistant' && message.metadata && (
              <div className="message-metadata">
                <div className="metadata-header">
                  <span className="model-badge" data-size={message.metadata.modelSize}>
                    {message.metadata.model}
                  </span>
                  <span className="decision-method">
                    {message.metadata.decisionMethod === 'rl_router' ? '🤖 RL Router' : '⚙️ Heuristic'}
                  </span>
                </div>

                <div className="metrics-grid">
                  <div className="metric">
                    <span className="metric-label">⚡ Energy</span>
                    <span className="metric-value">{message.metadata.energy.toFixed(2)} J</span>
                  </div>
                  <div className="metric">
                    <span className="metric-label">🌍 Carbon</span>
                    <span className="metric-value">{message.metadata.carbon.toFixed(4)} g CO₂</span>
                  </div>
                  <div className="metric">
                    <span className="metric-label">🎯 Complexity</span>
                    <span className="metric-value">{(message.metadata.complexity * 100).toFixed(0)}%</span>
                  </div>
                  <div className="metric">
                    <span className="metric-label">📊 Accuracy</span>
                    <span className="metric-value">{message.metadata.accuracyReq}</span>
                  </div>
                </div>

                {message.metadata.optimizationStats.optimization_applied && (
                  <div className="optimization-info">
                    <span className="optimization-badge">
                      ✨ Prompt Optimized: {message.metadata.optimizationStats.tokens_saved} tokens saved
                    </span>
                  </div>
                )}

                <div className="savings-info">
                  <span className="savings-badge">
                    💚 {message.metadata.savings.energy_saved_percent.toFixed(1)}% energy saved vs {message.metadata.savings.baseline_model}
                  </span>
                </div>

                {message.metadata.alternatives && message.metadata.alternatives.length > 0 && (
                  <details className="alternatives-section">
                    <summary>Alternative models considered</summary>
                    <div className="alternatives-list">
                      {message.metadata.alternatives.map((alt, i) => (
                        <div key={i} className="alternative-model">
                          <span className="alt-name">{alt.model_name}</span>
                          <span className="alt-stats">
                            {alt.energy_joules.toFixed(2)}J, {alt.carbon_grams.toFixed(4)}g CO₂
                          </span>
                        </div>
                      ))}
                    </div>
                  </details>
                )}
              </div>
            )}

            {message.type === 'error' && (
              <div className="error-info">
                ⚠️ {message.content}
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="message assistant loading">
            <div className="loading-animation">
              <span></span>
              <span></span>
              <span></span>
            </div>
            <span className="loading-text">Routing to optimal model...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="input-container">
        <textarea
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask anything... (Press Enter to send)"
          disabled={isLoading || !sessionId}
          rows={1}
        />
        <button
          onClick={sendQuery}
          disabled={isLoading || !inputValue.trim() || !sessionId}
          className="send-button"
        >
          {isLoading ? '⏳' : '🚀'}
        </button>
      </div>
    </div>
  );
}

export default ChatInterface;
