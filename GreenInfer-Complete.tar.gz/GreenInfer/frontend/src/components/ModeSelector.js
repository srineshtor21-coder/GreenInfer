import React, { useState } from 'react';
import './ModeSelector.css';

function ModeSelector({ currentMode, onModeChange, onCustomBudget }) {
  const [showCustom, setShowCustom] = useState(false);
  const [customCarbon, setCustomCarbon] = useState(50);
  const [customEnergy, setCustomEnergy] = useState(1000);

  const modes = [
    {
      id: 'eco',
      name: '🌱 Eco Mode',
      description: 'Maximum sustainability, minimal energy use',
      carbonBudget: 10,
      energyBudget: 200,
      color: '#10b981'
    },
    {
      id: 'balanced',
      name: '⚖️ Balanced Mode',
      description: 'Balance between performance and efficiency',
      carbonBudget: 50,
      energyBudget: 1000,
      color: '#3b82f6'
    },
    {
      id: 'performance',
      name: '🚀 Performance Mode',
      description: 'Prioritize accuracy over energy efficiency',
      carbonBudget: 'Unlimited',
      energyBudget: 'Unlimited',
      color: '#8b5cf6'
    }
  ];

  const handleModeClick = (modeId) => {
    onModeChange(modeId);
    setShowCustom(false);
  };

  const handleCustomSubmit = (e) => {
    e.preventDefault();
    onCustomBudget(customCarbon, customEnergy);
    setShowCustom(false);
  };

  return (
    <div className="mode-selector">
      <h3>⚙️ Settings</h3>

      <div className="modes-list">
        {modes.map(mode => (
          <div
            key={mode.id}
            className={`mode-card ${currentMode === mode.id ? 'active' : ''}`}
            onClick={() => handleModeClick(mode.id)}
            style={{ borderColor: currentMode === mode.id ? mode.color : 'transparent' }}
          >
            <div className="mode-name">{mode.name}</div>
            <div className="mode-description">{mode.description}</div>
            <div className="mode-budgets">
              <div className="budget-item">
                <span className="budget-icon">🌍</span>
                <span className="budget-value">{mode.carbonBudget} {typeof mode.carbonBudget === 'number' ? 'g CO₂' : ''}</span>
              </div>
              <div className="budget-item">
                <span className="budget-icon">⚡</span>
                <span className="budget-value">{mode.energyBudget} {typeof mode.energyBudget === 'number' ? 'J' : ''}</span>
              </div>
            </div>
          </div>
        ))}

        <button
          className={`custom-mode-toggle ${currentMode === 'custom' || showCustom ? 'active' : ''}`}
          onClick={() => setShowCustom(!showCustom)}
        >
          🎛️ Custom Budget
        </button>

        {showCustom && (
          <form className="custom-budget-form" onSubmit={handleCustomSubmit}>
            <div className="form-group">
              <label htmlFor="carbonBudget">
                <span className="label-icon">🌍</span>
                Carbon Budget (g CO₂)
              </label>
              <input
                type="number"
                id="carbonBudget"
                value={customCarbon}
                onChange={(e) => setCustomCarbon(parseFloat(e.target.value))}
                min="1"
                step="1"
              />
            </div>

            <div className="form-group">
              <label htmlFor="energyBudget">
                <span className="label-icon">⚡</span>
                Energy Budget (Joules)
              </label>
              <input
                type="number"
                id="energyBudget"
                value={customEnergy}
                onChange={(e) => setCustomEnergy(parseFloat(e.target.value))}
                min="1"
                step="10"
              />
            </div>

            <button type="submit" className="submit-button">
              Apply Custom Budget
            </button>
          </form>
        )}
      </div>

      <div className="mode-info">
        <h4>💡 How it works</h4>
        <ul className="info-list">
          <li>🧠 Analyzes query complexity</li>
          <li>⚖️ Estimates energy requirements</li>
          <li>🎯 Routes to optimal model</li>
          <li>📊 Tracks environmental impact</li>
        </ul>
      </div>
    </div>
  );
}

export default ModeSelector;
