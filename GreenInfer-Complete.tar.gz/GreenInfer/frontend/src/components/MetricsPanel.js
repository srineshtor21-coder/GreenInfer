import React from 'react';
import './MetricsPanel.css';

function MetricsPanel({ sessionStats, carbonIntensity }) {
  if (!sessionStats) return null;

  const carbonUsedPercent = (sessionStats.carbon_used / sessionStats.carbon_budget) * 100;
  const energyUsedPercent = (sessionStats.energy_used / sessionStats.energy_budget) * 100;

  const getStatusColor = (percent) => {
    if (percent < 50) return '#10b981'; // green
    if (percent < 80) return '#f59e0b'; // yellow
    return '#ef4444'; // red
  };

  return (
    <div className="metrics-panel">
      <h3>📊 Session Metrics</h3>

      <div className="metric-card">
        <div className="metric-header">
          <span className="metric-icon">🌍</span>
          <span className="metric-title">Carbon Usage</span>
        </div>
        <div className="metric-bar-container">
          <div 
            className="metric-bar" 
            style={{ 
              width: `${Math.min(carbonUsedPercent, 100)}%`,
              backgroundColor: getStatusColor(carbonUsedPercent)
            }}
          />
        </div>
        <div className="metric-values">
          <span className="metric-current">{sessionStats.carbon_used.toFixed(2)} g CO₂</span>
          <span className="metric-budget">/ {sessionStats.carbon_budget.toFixed(0)} g</span>
        </div>
        <div className="metric-remaining">
          <span style={{ color: getStatusColor(carbonUsedPercent) }}>
            {sessionStats.carbon_remaining.toFixed(2)} g remaining
          </span>
        </div>
      </div>

      <div className="metric-card">
        <div className="metric-header">
          <span className="metric-icon">⚡</span>
          <span className="metric-title">Energy Usage</span>
        </div>
        <div className="metric-bar-container">
          <div 
            className="metric-bar" 
            style={{ 
              width: `${Math.min(energyUsedPercent, 100)}%`,
              backgroundColor: getStatusColor(energyUsedPercent)
            }}
          />
        </div>
        <div className="metric-values">
          <span className="metric-current">{sessionStats.energy_used.toFixed(0)} J</span>
          <span className="metric-budget">/ {sessionStats.energy_budget.toFixed(0)} J</span>
        </div>
        <div className="metric-remaining">
          <span style={{ color: getStatusColor(energyUsedPercent) }}>
            {sessionStats.energy_remaining.toFixed(0)} J remaining
          </span>
        </div>
      </div>

      <div className="metric-card compact">
        <div className="compact-metric">
          <span className="compact-label">Queries Processed</span>
          <span className="compact-value">{sessionStats.queries_processed}</span>
        </div>
      </div>

      <div className="metric-card compact">
        <div className="compact-metric">
          <span className="compact-label">Current Mode</span>
          <span className="compact-value mode-badge" data-mode={sessionStats.mode}>
            {sessionStats.mode}
          </span>
        </div>
      </div>

      {carbonIntensity && (
        <div className="info-box">
          <span className="info-icon">🏭</span>
          <div className="info-content">
            <div className="info-label">Grid Carbon Intensity</div>
            <div className="info-value">
              {carbonIntensity.carbon_intensity_g_per_kwh} g CO₂/kWh
            </div>
            <div className="info-sublabel">{carbonIntensity.region}</div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MetricsPanel;
