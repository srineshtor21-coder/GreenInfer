import React, { useState, useEffect } from 'react';
import './AnalyticsDashboard.css';

function AnalyticsDashboard({ apiUrl }) {
  const [analytics, setAnalytics] = useState(null);
  const [savings, setSavings] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
    const interval = setInterval(fetchAnalytics, 10000); // Refresh every 10s
    return () => clearInterval(interval);
  }, []);

  const fetchAnalytics = async () => {
    try {
      const [analyticsRes, savingsRes] = await Promise.all([
        fetch(`${apiUrl}/analytics/decisions`),
        fetch(`${apiUrl}/analytics/savings`)
      ]);

      const analyticsData = await analyticsRes.json();
      const savingsData = await savingsRes.json();

      setAnalytics(analyticsData);
      setSavings(savingsData);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching analytics:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="analytics-loading">
        <div className="loading-spinner"></div>
        <p>Loading analytics...</p>
      </div>
    );
  }

  if (!analytics || analytics.total_decisions === 0) {
    return (
      <div className="analytics-empty">
        <h2>📊 No Data Yet</h2>
        <p>Start using the chatbot to see analytics on routing decisions and environmental impact!</p>
      </div>
    );
  }

  return (
    <div className="analytics-dashboard">
      <h2>📊 Analytics Dashboard</h2>

      <div className="analytics-grid">
        {/* Total Decisions */}
        <div className="analytics-card highlight">
          <div className="card-icon">🎯</div>
          <div className="card-content">
            <div className="card-value">{analytics.total_decisions}</div>
            <div className="card-label">Total Queries Processed</div>
          </div>
        </div>

        {/* Energy Saved */}
        <div className="analytics-card highlight">
          <div className="card-icon">⚡</div>
          <div className="card-content">
            <div className="card-value">{savings.total_energy_saved.toFixed(0)} J</div>
            <div className="card-label">Energy Saved</div>
            <div className="card-sublabel">
              {savings.savings_percentage.toFixed(1)}% reduction
            </div>
          </div>
        </div>

        {/* Carbon Saved */}
        <div className="analytics-card highlight">
          <div className="card-icon">🌍</div>
          <div className="card-content">
            <div className="card-value">{savings.total_carbon_saved.toFixed(2)} g</div>
            <div className="card-label">CO₂ Emissions Avoided</div>
            <div className="card-sublabel">
              vs. always using large model
            </div>
          </div>
        </div>

        {/* Average Energy */}
        <div className="analytics-card">
          <div className="card-icon">📊</div>
          <div className="card-content">
            <div className="card-value">{analytics.avg_energy.toFixed(1)} J</div>
            <div className="card-label">Avg Energy per Query</div>
          </div>
        </div>

        {/* Average Carbon */}
        <div className="analytics-card">
          <div className="card-icon">📈</div>
          <div className="card-content">
            <div className="card-value">{analytics.avg_carbon.toFixed(4)} g</div>
            <div className="card-label">Avg Carbon per Query</div>
          </div>
        </div>
      </div>

      {/* Model Usage Distribution */}
      <div className="analytics-section">
        <h3>🤖 Model Usage Distribution</h3>
        <div className="chart-container">
          {Object.entries(analytics.by_model).map(([model, count]) => {
            const percentage = (count / analytics.total_decisions * 100).toFixed(1);
            return (
              <div key={model} className="chart-bar-item">
                <div className="bar-label">
                  <span className="bar-name">{model}</span>
                  <span className="bar-count">{count} queries ({percentage}%)</span>
                </div>
                <div className="bar-container">
                  <div 
                    className="bar-fill" 
                    style={{ width: `${percentage}%` }}
                    data-model={model}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Decision Method Distribution */}
      <div className="analytics-section">
        <h3>🧠 Decision Method Distribution</h3>
        <div className="chart-container">
          {Object.entries(analytics.by_method).map(([method, count]) => {
            const percentage = (count / analytics.total_decisions * 100).toFixed(1);
            const methodLabels = {
              'rl_router': '🤖 RL Router',
              'heuristic': '⚙️ Heuristic',
              'budget_constrained': '💰 Budget Constrained',
              'budget_exhausted': '⚠️ Budget Exhausted'
            };
            return (
              <div key={method} className="chart-bar-item">
                <div className="bar-label">
                  <span className="bar-name">{methodLabels[method] || method}</span>
                  <span className="bar-count">{count} queries ({percentage}%)</span>
                </div>
                <div className="bar-container">
                  <div 
                    className="bar-fill" 
                    style={{ width: `${percentage}%` }}
                    data-method={method}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Environmental Impact Comparison */}
      <div className="analytics-section comparison">
        <h3>🌱 Environmental Impact Comparison</h3>
        <div className="comparison-grid">
          <div className="comparison-card baseline">
            <div className="comparison-label">Baseline (Always Large Model)</div>
            <div className="comparison-metrics">
              <div className="comparison-metric">
                <span className="metric-label">Energy</span>
                <span className="metric-value">{savings.baseline_energy.toFixed(0)} J</span>
              </div>
              <div className="comparison-metric">
                <span className="metric-label">Carbon</span>
                <span className="metric-value">{savings.baseline_carbon.toFixed(2)} g CO₂</span>
              </div>
            </div>
          </div>

          <div className="comparison-arrow">→</div>

          <div className="comparison-card green">
            <div className="comparison-label">Green Orchestrator</div>
            <div className="comparison-metrics">
              <div className="comparison-metric">
                <span className="metric-label">Energy</span>
                <span className="metric-value">{savings.actual_energy.toFixed(0)} J</span>
              </div>
              <div className="comparison-metric">
                <span className="metric-label">Carbon</span>
                <span className="metric-value">{savings.actual_carbon.toFixed(2)} g CO₂</span>
              </div>
            </div>
          </div>
        </div>

        <div className="savings-summary">
          <div className="savings-badge">
            💚 {savings.savings_percentage.toFixed(1)}% More Sustainable
          </div>
          <p className="savings-description">
            By intelligently routing {savings.queries_analyzed} queries, we saved{' '}
            {savings.total_energy_saved.toFixed(0)} Joules of energy and avoided{' '}
            {savings.total_carbon_saved.toFixed(2)} grams of CO₂ emissions.
          </p>
        </div>
      </div>

      {/* Refresh Button */}
      <div className="analytics-actions">
        <button onClick={fetchAnalytics} className="refresh-button">
          🔄 Refresh Analytics
        </button>
      </div>
    </div>
  );
}

export default AnalyticsDashboard;
