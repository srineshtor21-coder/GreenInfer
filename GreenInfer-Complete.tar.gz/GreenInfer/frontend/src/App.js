import React, { useState, useEffect } from 'react';
import './App.css';
import ChatInterface from './components/ChatInterface';
import MetricsPanel from './components/MetricsPanel';
import ModeSelector from './components/ModeSelector';
import AnalyticsDashboard from './components/AnalyticsDashboard';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

function App() {
  const [sessionId, setSessionId] = useState(null);
  const [mode, setMode] = useState('balanced');
  const [sessionStats, setSessionStats] = useState(null);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [carbonIntensity, setCarbonIntensity] = useState(null);

  // Initialize session on mount
  useEffect(() => {
    createSession();
    fetchCarbonIntensity();
  }, []);

  // Refresh session stats periodically
  useEffect(() => {
    if (sessionId) {
      const interval = setInterval(() => {
        fetchSessionStatus();
      }, 5000);
      
      return () => clearInterval(interval);
    }
  }, [sessionId]);

  const createSession = async () => {
    try {
      const response = await fetch(`${API_URL}/session/create`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      const data = await response.json();
      setSessionId(data.session_id);
      setMode(data.mode);
      
      // Initial session status
      await fetchSessionStatus(data.session_id);
    } catch (error) {
      console.error('Error creating session:', error);
    }
  };

  const fetchSessionStatus = async (sid = sessionId) => {
    if (!sid) return;
    
    try {
      const response = await fetch(`${API_URL}/session/${sid}/status`);
      const data = await response.json();
      setSessionStats(data);
    } catch (error) {
      console.error('Error fetching session status:', error);
    }
  };

  const fetchCarbonIntensity = async () => {
    try {
      const response = await fetch(`${API_URL}/carbon/intensity?region=US-TX`);
      const data = await response.json();
      setCarbonIntensity(data);
    } catch (error) {
      console.error('Error fetching carbon intensity:', error);
    }
  };

  const handleModeChange = async (newMode) => {
    try {
      const response = await fetch(`${API_URL}/settings/mode`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ mode: newMode })
      });
      
      const data = await response.json();
      setMode(data.mode);
      
      // Refresh session status
      await fetchSessionStatus();
    } catch (error) {
      console.error('Error updating mode:', error);
    }
  };

  const handleCustomBudget = async (carbonBudget, energyBudget) => {
    try {
      const response = await fetch(`${API_URL}/settings/custom`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          carbon_budget: carbonBudget,
          energy_budget: energyBudget
        })
      });
      
      const data = await response.json();
      setMode('custom');
      
      // Refresh session status
      await fetchSessionStatus();
    } catch (error) {
      console.error('Error setting custom budget:', error);
    }
  };

  return (
    <div className="App">
      <header className="app-header">
        <div className="header-content">
          <h1>🌱 Green AI Orchestrator</h1>
          <p className="tagline">Sustainable AI Inference Through Intelligent Model Routing</p>
        </div>
        
        <div className="header-actions">
          <button 
            className={`analytics-toggle ${showAnalytics ? 'active' : ''}`}
            onClick={() => setShowAnalytics(!showAnalytics)}
          >
            {showAnalytics ? '💬 Chat' : '📊 Analytics'}
          </button>
        </div>
      </header>

      <div className="app-content">
        {!showAnalytics ? (
          <>
            <div className="sidebar">
              <ModeSelector 
                currentMode={mode}
                onModeChange={handleModeChange}
                onCustomBudget={handleCustomBudget}
              />
              
              {sessionStats && (
                <MetricsPanel 
                  sessionStats={sessionStats}
                  carbonIntensity={carbonIntensity}
                />
              )}
              
              <div className="info-card">
                <h3>🌍 Environmental Impact</h3>
                <p className="info-text">
                  This orchestrator reduces AI carbon emissions by intelligently 
                  routing queries to the most energy-efficient model that meets 
                  your accuracy requirements.
                </p>
              </div>
            </div>

            <div className="main-content">
              <ChatInterface 
                sessionId={sessionId}
                mode={mode}
                apiUrl={API_URL}
                onQueryComplete={fetchSessionStatus}
              />
            </div>
          </>
        ) : (
          <div className="analytics-view">
            <AnalyticsDashboard apiUrl={API_URL} />
          </div>
        )}
      </div>

      <footer className="app-footer">
        <p>Built with ♻️ by [Your Name] | Open Source Green AI Framework</p>
        {carbonIntensity && (
          <p className="carbon-intensity">
            Grid Carbon Intensity: {carbonIntensity.carbon_intensity_g_per_kwh}g CO₂/kWh ({carbonIntensity.region})
          </p>
        )}
      </footer>
    </div>
  );
}

export default App;
