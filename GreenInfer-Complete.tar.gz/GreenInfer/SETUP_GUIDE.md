# 🚀 Green AI Orchestrator - Complete Setup Guide

## 📋 Table of Contents
1. [Prerequisites](#prerequisites)
2. [Project Structure](#project-structure)
3. [Step-by-Step Setup](#step-by-step-setup)
4. [Training Your Models](#training-your-models)
5. [Running the Application](#running-the-application)
6. [Testing & Validation](#testing--validation)
7. [Deployment](#deployment)
8. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Software
- **Python 3.9+** (Download from python.org)
- **Node.js 16+** (Download from nodejs.org)
- **Git** (for version control)

### Hardware Requirements
- **Minimum**: 8GB RAM, modern CPU
- **Recommended**: 16GB+ RAM, GPU for faster ML model training
- **Storage**: ~5GB for dependencies and models

### API Keys (Optional but Recommended)
- **HuggingFace**: For Mistral-7B access
- **OpenAI**: For GPT-4 (large model demo)

---

## Project Structure

```
green-ai-orchestrator/
├── backend/
│   ├── api.py                    # Flask REST API
│   ├── orchestrator.py           # Main orchestration engine
│   ├── energy_estimator.py       # Energy & carbon estimation
│   ├── rl_router.py              # Reinforcement learning router
│   └── model_registry.py         # Dynamic model registry
├── models/
│   └── task_complexity_model.py  # Task complexity analyzer
├── frontend/
│   ├── src/
│   │   ├── App.js
│   │   ├── components/
│   │   │   ├── ChatInterface.js
│   │   │   ├── MetricsPanel.js
│   │   │   ├── ModeSelector.js
│   │   │   └── AnalyticsDashboard.js
│   │   └── App.css
│   ├── public/
│   │   └── index.html
│   └── package.json
├── data/                         # Created at runtime
│   ├── energy_history.json
│   └── emissions/
├── configs/
│   └── model_registry.json       # Created at first run
├── requirements.txt
└── README.md
```

---

## Step-by-Step Setup

### Step 1: Clone/Download Project

```bash
# If using Git
git clone <your-repo-url>
cd green-ai-orchestrator

# Or just download and extract the ZIP file
```

### Step 2: Backend Setup

```bash
# Navigate to backend
cd green-ai-orchestrator

# Create virtual environment (recommended)
python3 -m venv venv

# Activate virtual environment
# On Mac/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install Python dependencies
pip install -r requirements.txt
```

### Step 3: Environment Variables

Create a `.env` file in the root directory:

```env
# API Keys (optional)
HUGGINGFACE_API_KEY=your_huggingface_key
OPENAI_API_KEY=your_openai_key

# Flask Configuration
SECRET_KEY=your_random_secret_key_here
FLASK_ENV=development

# Carbon Tracking (optional)
CARBON_TRACKING_REGION=US-TX
```

### Step 4: Frontend Setup

```bash
# Navigate to frontend
cd frontend

# Install npm dependencies
npm install

# Return to root
cd ..
```

### Step 5: Create Data Directories

```bash
# These will store runtime data
mkdir -p data/emissions
mkdir -p configs
mkdir -p models
```

---

## Training Your Models

### 1. Integrate Your Prompt Optimizer

Your pre-trained prompt optimizer on HuggingFace needs to be integrated:

**Edit `backend/orchestrator.py`**, find the `optimize_prompt` method (line ~115):

```python
def optimize_prompt(self, prompt: str) -> Tuple[str, Dict]:
    if self.prompt_optimizer is None:
        # Replace this section with your HuggingFace model
        from transformers import pipeline
        
        # Example - replace with your actual model
        optimizer = pipeline("text2text-generation", 
                           model="your-username/your-prompt-optimizer")
        optimized = optimizer(prompt)[0]['generated_text']
        
        # Calculate stats
        stats = {
            'original_tokens': len(prompt.split()),
            'optimized_tokens': len(optimized.split()),
            'tokens_saved': len(prompt.split()) - len(optimized.split()),
            'optimization_applied': True
        }
        
        return optimized, stats
    # ... rest of code
```

### 2. Train Task Complexity Model

```bash
# Run the training script
cd models
python task_complexity_model.py

# This will:
# 1. Load your training data (you'll need to create this)
# 2. Fine-tune DistilBERT
# 3. Save trained model as task_complexity_best.pth
```

**Create training data** (`data/complexity_training.json`):

```json
[
  {
    "text": "What is 2+2?",
    "complexity_score": 0.1,
    "accuracy_requirement": 0
  },
  {
    "text": "Explain quantum entanglement",
    "complexity_score": 0.8,
    "accuracy_requirement": 2
  }
]
```

### 3. Train RL Router (Optional but Recommended)

After collecting some usage data:

```python
from backend.orchestrator import GreenAIOrchestrator

orchestrator = GreenAIOrchestrator()

# Training data format
training_data = [
    {
        'prompt': 'What is the capital of France?',
        'accuracy': 1.0,
        'energy': 50.0,
        'model_size': 'small'
    },
    # ... add more examples
]

orchestrator.train_rl_router(training_data, num_epochs=100)
# Saves to models/rl_router.pth
```

---

## Running the Application

### Development Mode

**Terminal 1 - Backend:**
```bash
cd backend
python api.py
# Server starts on http://localhost:5000
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
# Opens browser to http://localhost:3000
```

### Production Build

```bash
# Build frontend
cd frontend
npm run build

# Serve with Flask (backend/api.py needs modification)
# Or use nginx/Apache to serve build/
```

---

## Testing & Validation

### 1. Test Backend API

```bash
# Health check
curl http://localhost:5000/api/health

# Create session
curl -X POST http://localhost:5000/api/session/create

# Send query
curl -X POST http://localhost:5000/api/query \
  -H "Content-Type: application/json" \
  -d '{"prompt": "What is AI?", "session_id": "test"}'
```

### 2. Test Models

```python
# Test complexity analyzer
from models.task_complexity_model import ComplexityAnalyzer

analyzer = ComplexityAnalyzer()
result = analyzer.analyze("Write a sorting algorithm")
print(result)

# Test energy estimator
from backend.energy_estimator import EnergyEstimator

estimator = EnergyEstimator()
estimate = estimator.proxy_estimate('medium', token_count=100)
print(estimate)
```

### 3. Integration Test

```python
from backend.orchestrator import GreenAIOrchestrator

orchestrator = GreenAIOrchestrator()
result = orchestrator.execute_query(
    prompt="Explain machine learning",
    session_id="integration_test"
)
print(f"Model: {result['routing_decision']['model_name']}")
print(f"Energy: {result['routing_decision']['estimated_energy_joules']} J")
```

---

## Deployment

### Option 1: Local Deployment (Demo)
- Run backend and frontend on your computer
- Access via `localhost:3000`
- Good for presentations and demos

### Option 2: Cloud Deployment (Recommended for College Apps)

**Backend (Heroku, Railway, or DigitalOcean):**
1. Add `Procfile`:
   ```
   web: cd backend && python api.py
   ```
2. Deploy to hosting service
3. Note the backend URL

**Frontend (Vercel, Netlify, or GitHub Pages):**
1. Update API URL in `frontend/src/App.js`:
   ```javascript
   const API_URL = 'https://your-backend-url.com/api';
   ```
2. Build and deploy:
   ```bash
   cd frontend
   npm run build
   # Deploy build/ folder
   ```

### Option 3: Custom Domain
1. Purchase domain (e.g., from Namecheap, GoDaddy)
2. Point DNS to your hosting service
3. Configure SSL certificate
4. Update all links in README and portfolio

---

## Troubleshooting

### Common Issues

**1. "Module not found" errors**
```bash
# Make sure virtual environment is activated
source venv/bin/activate  # Mac/Linux
venv\Scripts\activate     # Windows

# Reinstall dependencies
pip install -r requirements.txt
```

**2. Frontend can't connect to backend**
- Check backend is running: `curl http://localhost:5000/api/health`
- Check CORS settings in `backend/api.py`
- Verify `proxy` in `frontend/package.json`

**3. Model not loading**
```bash
# Check model file exists
ls models/task_complexity_best.pth
ls models/rl_router.pth

# Check permissions
chmod +x models/*.pth
```

**4. Out of memory**
- Use smaller batch sizes for training
- Run models on CPU if GPU memory is insufficient
- Close other applications

**5. CodeCarbon not tracking**
```python
# Install platform-specific dependencies
# Mac:
pip install py-cpuinfo
# Linux:
pip install psutil
# Windows:
pip install wmi
```

---

## Next Steps

### For College Applications

1. **Document Everything**
   - Take screenshots of the working app
   - Record demo video
   - Export analytics and create graphs
   - Write research paper (methods, results, discussion)

2. **Create Presentation Materials**
   - PowerPoint with system architecture
   - Poster for science fairs
   - GitHub README with badges and stats
   - Portfolio website showcasing the project

3. **Collect Data & Results**
   - Run benchmark experiments
   - Calculate energy savings percentages
   - Create comparison charts (baseline vs orchestrator)
   - Document environmental impact

4. **Polish the Code**
   - Add comprehensive comments
   - Write unit tests
   - Create API documentation
   - Clean up any TODOs

5. **Share & Promote**
   - Open source on GitHub
   - Write blog post about the project
   - Submit to competitions (ISEF, Regeneron STS)
   - Share on LinkedIn/Twitter

---

## Timeline Checkpoint (From Now Until April)

### Week 1-2 (Feb 15-28): Core Development
- ✅ Set up project structure
- ✅ Integrate prompt optimizer
- ✅ Train complexity model
- ✅ Test basic orchestration

### Week 3-4 (Mar 1-14): Web Interface
- Build and polish frontend
- Implement all three modes
- Add analytics dashboard
- Test end-to-end flow

### Week 5-6 (Mar 15-28): Experiments & Data
- Run benchmark experiments
- Collect energy/accuracy data
- Create comparison graphs
- Document results

### Week 7 (Mar 29-Apr 5): Polish & Presentation
- Write research paper
- Create presentation materials
- Record demo video
- Clean GitHub repository
- Deploy to custom domain

---

## Support & Resources

- **Documentation**: See README.md for architecture details
- **Issues**: Check GitHub issues or create new one
- **Contact**: [Your Email]

**Good luck with your project! You're building something truly impressive. 🌱**
