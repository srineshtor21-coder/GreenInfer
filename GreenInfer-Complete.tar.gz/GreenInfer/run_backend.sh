#!/bin/bash
echo "🌱 Starting Green AI Orchestrator Backend..."
echo ""

# Create necessary directories
mkdir -p data/emissions
mkdir -p configs
mkdir -p models

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -q -r requirements.txt

# Start Flask backend
echo ""
echo "✅ Backend ready! Starting server on http://localhost:5000"
echo ""
cd backend
python api.py
