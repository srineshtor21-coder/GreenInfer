#!/bin/bash
echo "🌱 Starting Green AI Orchestrator Frontend..."
echo ""

cd frontend

# Check if node_modules exists
if [ ! -d "node_modules" ]; then
    echo "Installing npm dependencies..."
    npm install
fi

echo ""
echo "✅ Frontend ready! Starting development server..."
echo "   Open http://localhost:3000 in your browser"
echo ""
npm start
