"""
Green AI Orchestrator Engine
Main orchestration logic that integrates all components for sustainable AI routing
"""

import sys
import os
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import json
from datetime import datetime

# Add backend to path
sys.path.append(os.path.dirname(__file__))

from energy_estimator import EnergyEstimator, EnergyMetrics
from rl_router import RLRouter, RLState
from model_registry import ModelRegistry, ModelConfig

@dataclass
class OrchestratorConfig:
    """Configuration for orchestrator behavior"""
    mode: str = 'balanced'  # 'eco', 'balanced', 'performance'
    carbon_budget_per_query: Optional[float] = None  # grams CO2
    energy_budget_per_query: Optional[float] = None  # joules
    lambda_energy: float = 0.5  # RL reward weight for energy
    use_rl_router: bool = True
    enable_carbon_aware: bool = False
    grid_region: str = 'US-TX'
    min_accuracy_threshold: float = 0.6
    
    # Session budgets
    session_carbon_budget: float = 100.0  # grams per session
    session_energy_budget: float = 5000.0  # joules per session


@dataclass
class RoutingDecision:
    """Result of orchestrator routing decision"""
    model_id: str
    model_name: str
    model_size: str
    estimated_energy: float
    estimated_carbon: float
    estimated_time: float
    complexity_score: float
    accuracy_requirement: str
    task_type: str
    decision_method: str  # 'rl', 'heuristic', 'budget_constrained'
    alternatives_considered: List[Dict]
    carbon_aware: bool
    grid_carbon_intensity: float
    
    def to_dict(self):
        return {
            'model_id': self.model_id,
            'model_name': self.model_name,
            'model_size': self.model_size,
            'estimated_energy_joules': self.estimated_energy,
            'estimated_carbon_grams': self.estimated_carbon,
            'estimated_time_seconds': self.estimated_time,
            'complexity_score': self.complexity_score,
            'accuracy_requirement': self.accuracy_requirement,
            'task_type': self.task_type,
            'decision_method': self.decision_method,
            'alternatives_considered': self.alternatives_considered,
            'carbon_aware': self.carbon_aware,
            'grid_carbon_intensity': self.grid_carbon_intensity
        }


@dataclass
class SessionState:
    """Track state across a user session"""
    session_id: str
    carbon_used: float = 0.0
    energy_used: float = 0.0
    queries_processed: int = 0
    created_at: str = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()


class GreenAIOrchestrator:
    """
    Main orchestration engine for sustainable AI inference
    Integrates complexity analysis, energy estimation, RL routing, and model registry
    """
    
    def __init__(self, config: Optional[OrchestratorConfig] = None,
                 prompt_optimizer=None):
        """
        Initialize orchestrator
        
        Args:
            config: OrchestratorConfig object
            prompt_optimizer: your pre-trained prompt optimizer
        """
        self.config = config or OrchestratorConfig()
        self.prompt_optimizer = prompt_optimizer
        
        # Initialize components
        self.energy_estimator = EnergyEstimator()
        self.model_registry = ModelRegistry()
        self.rl_router = RLRouter(
            num_models=3,
            lambda_energy=self.config.lambda_energy
        ) if self.config.use_rl_router else None
        
        # Session management
        self.sessions: Dict[str, SessionState] = {}
        
        # Logging
        self.decision_log = []
        
        # Load RL model if exists
        if self.config.use_rl_router and os.path.exists('models/rl_router.pth'):
            self.rl_router.load_model('models/rl_router.pth')
        
        # Mode-specific budgets
        self.mode_configs = {
            'eco': {
                'carbon_budget': 10.0,
                'energy_budget': 200.0,
                'min_accuracy': 0.5
            },
            'balanced': {
                'carbon_budget': 50.0,
                'energy_budget': 1000.0,
                'min_accuracy': 0.7
            },
            'performance': {
                'carbon_budget': None,
                'energy_budget': None,
                'min_accuracy': 0.85
            }
        }
    
    def set_mode(self, mode: str):
        """Change orchestrator mode"""
        if mode not in self.mode_configs:
            raise ValueError(f"Invalid mode: {mode}. Choose from: eco, balanced, performance")
        
        self.config.mode = mode
        mode_config = self.mode_configs[mode]
        self.config.carbon_budget_per_query = mode_config['carbon_budget']
        self.config.energy_budget_per_query = mode_config['energy_budget']
        self.config.min_accuracy_threshold = mode_config['min_accuracy']
    
    def create_session(self, session_id: str) -> SessionState:
        """Create a new user session"""
        session = SessionState(session_id=session_id)
        self.sessions[session_id] = session
        return session
    
    def get_session(self, session_id: str) -> Optional[SessionState]:
        """Get existing session or create new one"""
        if session_id not in self.sessions:
            return self.create_session(session_id)
        return self.sessions[session_id]
    
    def optimize_prompt(self, prompt: str) -> Tuple[str, Dict]:
        """
        Optimize prompt using your pre-trained optimizer
        
        Returns:
            (optimized_prompt, optimization_stats)
        """
        if self.prompt_optimizer is None:
            # No optimization
            return prompt, {
                'original_tokens': len(prompt.split()),
                'optimized_tokens': len(prompt.split()),
                'tokens_saved': 0,
                'optimization_applied': False
            }
        
        # Call your HuggingFace prompt optimizer here
        # This is a placeholder - replace with your actual optimizer
        optimized = self.prompt_optimizer.optimize(prompt)
        
        stats = {
            'original_tokens': len(prompt.split()),
            'optimized_tokens': len(optimized.split()),
            'tokens_saved': len(prompt.split()) - len(optimized.split()),
            'optimization_applied': True
        }
        
        return optimized, stats
    
    def analyze_complexity(self, prompt: str) -> Dict:
        """
        Analyze task complexity
        This would call your trained complexity model
        """
        # Placeholder - replace with your trained model
        from models.task_complexity_model import ComplexityAnalyzer
        
        analyzer = ComplexityAnalyzer()
        return analyzer.analyze(prompt)
    
    def _heuristic_routing(self, complexity_score: float, 
                          accuracy_requirement: str,
                          task_type: str,
                          available_models: List[ModelConfig]) -> ModelConfig:
        """
        Fallback heuristic routing when RL is not used
        """
        # Simple rule-based routing
        if accuracy_requirement == 'low' or complexity_score < 0.3:
            # Prefer small models
            candidates = [m for m in available_models if m.model_size == 'small']
        elif accuracy_requirement == 'high' or complexity_score > 0.7:
            # May need large model
            candidates = [m for m in available_models if m.model_size == 'large']
            if not candidates:
                candidates = [m for m in available_models if m.model_size == 'medium']
        else:
            # Medium models
            candidates = [m for m in available_models if m.model_size == 'medium']
        
        if not candidates:
            candidates = available_models
        
        # Sort by energy efficiency
        candidates.sort(key=lambda m: m.avg_energy_joules)
        
        return candidates[0]
    
    def route_query(self, prompt: str, session_id: str,
                   complexity_analysis: Optional[Dict] = None) -> RoutingDecision:
        """
        Main routing logic - decides which model to use
        
        Args:
            prompt: user query (after optimization)
            session_id: session identifier
            complexity_analysis: pre-computed complexity analysis
        
        Returns:
            RoutingDecision object
        """
        session = self.get_session(session_id)
        
        # Get complexity analysis if not provided
        if complexity_analysis is None:
            complexity_analysis = self.analyze_complexity(prompt)
        
        complexity_score = complexity_analysis['complexity_score']
        accuracy_requirement = complexity_analysis['accuracy_requirement']
        task_type = complexity_analysis['task_type']
        token_count = complexity_analysis['token_count']
        
        # Get carbon intensity if carbon-aware
        carbon_intensity = 400.0
        if self.config.enable_carbon_aware:
            carbon_intensity = self.energy_estimator.get_carbon_intensity(
                self.config.grid_region
            )
        
        # Get available models
        available_models = self.model_registry.get_active_models()
        
        # Apply budget constraints
        if self.config.carbon_budget_per_query:
            available_models = [
                m for m in available_models
                if m.avg_carbon_grams <= self.config.carbon_budget_per_query
            ]
        
        if self.config.energy_budget_per_query:
            available_models = [
                m for m in available_models
                if m.avg_energy_joules <= self.config.energy_budget_per_query
            ]
        
        # Check session budget
        remaining_carbon = self.config.session_carbon_budget - session.carbon_used
        remaining_energy = self.config.session_energy_budget - session.energy_used
        
        available_models = [
            m for m in available_models
            if m.avg_carbon_grams <= remaining_carbon 
            and m.avg_energy_joules <= remaining_energy
        ]
        
        if not available_models:
            # Budget exhausted - must use smallest model
            all_models = self.model_registry.get_active_models()
            all_models.sort(key=lambda m: m.avg_energy_joules)
            selected_model = all_models[0]
            decision_method = 'budget_exhausted'
        elif self.config.use_rl_router and self.rl_router:
            # Use RL router
            rl_decision = self.rl_router.route(
                complexity_score=complexity_score,
                accuracy_requirement=accuracy_requirement,
                token_count=token_count,
                task_type=task_type,
                carbon_intensity=carbon_intensity,
                session_carbon_used=session.carbon_used,
                session_carbon_budget=self.config.session_carbon_budget,
                training=False
            )
            
            model_index = rl_decision['model_index']
            model_sizes = ['small', 'medium', 'large']
            
            # Find best model of chosen size from available models
            target_size = model_sizes[model_index] if model_index < len(model_sizes) else 'medium'
            size_models = [m for m in available_models if m.model_size == target_size]
            
            if size_models:
                selected_model = min(size_models, key=lambda m: m.avg_energy_joules)
            else:
                # Fallback
                selected_model = min(available_models, key=lambda m: m.avg_energy_joules)
            
            decision_method = 'rl_router'
        else:
            # Heuristic routing
            selected_model = self._heuristic_routing(
                complexity_score, accuracy_requirement, task_type, available_models
            )
            decision_method = 'heuristic'
        
        # Get energy estimate
        energy_estimate = self.energy_estimator.estimate(
            model_name=selected_model.model_id,
            model_size=selected_model.model_size,
            token_count=token_count,
            task_type=task_type,
            complexity_score=complexity_score
        )
        
        # Create alternatives list
        alternatives = []
        for model in available_models[:3]:  # Top 3 alternatives
            if model.model_id != selected_model.model_id:
                alt_estimate = self.energy_estimator.estimate(
                    model_name=model.model_id,
                    model_size=model.model_size,
                    token_count=token_count,
                    task_type=task_type,
                    complexity_score=complexity_score
                )
                alternatives.append({
                    'model_id': model.model_id,
                    'model_name': model.model_name,
                    'energy_joules': alt_estimate['energy_joules'],
                    'carbon_grams': alt_estimate['carbon_grams']
                })
        
        # Create decision
        decision = RoutingDecision(
            model_id=selected_model.model_id,
            model_name=selected_model.model_name,
            model_size=selected_model.model_size,
            estimated_energy=energy_estimate['energy_joules'],
            estimated_carbon=energy_estimate['carbon_grams'],
            estimated_time=energy_estimate['estimated_time_seconds'],
            complexity_score=complexity_score,
            accuracy_requirement=accuracy_requirement,
            task_type=task_type,
            decision_method=decision_method,
            alternatives_considered=alternatives,
            carbon_aware=self.config.enable_carbon_aware,
            grid_carbon_intensity=carbon_intensity
        )
        
        # Log decision
        self.decision_log.append({
            'timestamp': datetime.now().isoformat(),
            'session_id': session_id,
            'decision': decision.to_dict(),
            'prompt_length': len(prompt)
        })
        
        return decision
    
    def execute_query(self, prompt: str, session_id: str) -> Dict:
        """
        Full pipeline: optimize -> analyze -> route -> execute
        
        Returns:
            dict with response, metrics, and routing info
        """
        session = self.get_session(session_id)
        
        # 1. Optimize prompt
        optimized_prompt, opt_stats = self.optimize_prompt(prompt)
        
        # 2. Analyze complexity
        complexity = self.analyze_complexity(optimized_prompt)
        
        # 3. Route to model
        decision = self.route_query(optimized_prompt, session_id, complexity)
        
        # 4. Execute inference (placeholder - integrate your actual models)
        model_config = self.model_registry.get_model(decision.model_id)
        
        # This is where you'd call the actual model
        # For now, return a mock response
        response = f"[Response from {decision.model_name}]"
        
        # 5. Update session state
        session.carbon_used += decision.estimated_carbon
        session.energy_used += decision.estimated_energy
        session.queries_processed += 1
        
        # 6. Calculate savings
        baseline_model = self.model_registry.get_models_by_size('large')[0]
        baseline_estimate = self.energy_estimator.estimate(
            model_name=baseline_model.model_id,
            model_size='large',
            token_count=complexity['token_count'],
            task_type=complexity['task_type'],
            complexity_score=complexity['complexity_score']
        )
        
        savings = self.energy_estimator.calculate_savings(
            baseline_model=baseline_model.model_name,
            chosen_model=decision.model_name,
            baseline_energy=baseline_estimate['energy_joules'],
            chosen_energy=decision.estimated_energy
        )
        
        return {
            'response': response,
            'routing_decision': decision.to_dict(),
            'optimization_stats': opt_stats,
            'complexity_analysis': complexity,
            'savings': savings,
            'session_state': {
                'carbon_used': session.carbon_used,
                'carbon_remaining': self.config.session_carbon_budget - session.carbon_used,
                'energy_used': session.energy_used,
                'queries_processed': session.queries_processed
            }
        }
    
    def train_rl_router(self, training_data: List[Dict], num_epochs: int = 100):
        """
        Train the RL router on historical data
        
        Args:
            training_data: list of dicts with 'prompt', 'accuracy', 'energy', 'model_used'
            num_epochs: number of training epochs
        """
        if not self.config.use_rl_router or not self.rl_router:
            print("RL router not enabled")
            return
        
        for epoch in range(num_epochs):
            for data in training_data:
                # Analyze complexity
                complexity = self.analyze_complexity(data['prompt'])
                
                # Create state
                accuracy_req_map = {'low': 0, 'medium': 1, 'high': 2}
                state = self.rl_router.route(
                    complexity_score=complexity['complexity_score'],
                    accuracy_requirement=complexity['accuracy_requirement'],
                    token_count=complexity['token_count'],
                    task_type=complexity['task_type'],
                    training=True
                )['state']
                
                # Get action (model used)
                model_map = {'small': 0, 'medium': 1, 'large': 2}
                action = model_map.get(data.get('model_size', 'medium'), 1)
                
                # Calculate reward
                reward = self.rl_router.calculate_reward(
                    accuracy=data.get('accuracy', 0.7),
                    energy=data.get('energy', 500.0)
                )
                
                # Create next state (same as state for now)
                next_state = state
                
                # Store experience
                self.rl_router.store_experience(state, action, reward, next_state)
                
                # Train
                if self.rl_router.replay_buffer.size() >= 32:
                    loss = self.rl_router.train_step(batch_size=32)
            
            # Update target network every 10 epochs
            if epoch % 10 == 0:
                self.rl_router.update_target_network()
                self.rl_router.decay_epsilon()
                
                print(f"Epoch {epoch}: epsilon = {self.rl_router.epsilon:.3f}")
        
        # Save trained model
        os.makedirs('models', exist_ok=True)
        self.rl_router.save_model('models/rl_router.pth')
        print("RL router training complete")
    
    def export_metrics(self, filepath: str):
        """Export decision log and metrics"""
        with open(filepath, 'w') as f:
            json.dump({
                'config': {
                    'mode': self.config.mode,
                    'carbon_budget': self.config.carbon_budget_per_query,
                    'energy_budget': self.config.energy_budget_per_query
                },
                'decisions': self.decision_log,
                'sessions': {
                    sid: {
                        'carbon_used': s.carbon_used,
                        'energy_used': s.energy_used,
                        'queries': s.queries_processed
                    }
                    for sid, s in self.sessions.items()
                }
            }, f, indent=2)


if __name__ == "__main__":
    # Example usage
    orchestrator = GreenAIOrchestrator()
    orchestrator.set_mode('balanced')
    
    # Process a query
    result = orchestrator.execute_query(
        prompt="Write a Python function to sort a list",
        session_id="test_session_1"
    )
    
    print("Routing Decision:")
    print(f"  Model: {result['routing_decision']['model_name']}")
    print(f"  Energy: {result['routing_decision']['estimated_energy_joules']:.2f} J")
    print(f"  Carbon: {result['routing_decision']['estimated_carbon_grams']:.4f} g CO2")
    print(f"\nSavings vs Large Model:")
    print(f"  Energy: {result['savings']['energy_saved_percent']:.1f}%")
    print(f"  Carbon: {result['savings']['carbon_saved_grams']:.4f} g CO2")
