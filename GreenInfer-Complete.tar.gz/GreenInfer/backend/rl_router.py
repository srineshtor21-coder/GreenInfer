"""
Reinforcement Learning Router
Self-learning policy that optimizes model routing decisions based on accuracy-energy tradeoffs
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import random
import json
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass

@dataclass
class Experience:
    """Experience tuple for replay buffer"""
    state: np.ndarray
    action: int
    reward: float
    next_state: np.ndarray
    done: bool


class RLState:
    """State representation for RL agent"""
    
    def __init__(self, complexity_score: float, accuracy_requirement: int,
                 token_count: int, task_type_encoded: int,
                 carbon_intensity: float = 400.0,
                 session_carbon_used: float = 0.0,
                 session_carbon_budget: float = 100.0):
        """
        Args:
            complexity_score: 0-1 task complexity
            accuracy_requirement: 0 (low), 1 (medium), 2 (high)
            token_count: normalized token count
            task_type_encoded: encoded task type (0-5)
            carbon_intensity: current grid carbon intensity
            session_carbon_used: carbon used in current session
            session_carbon_budget: total carbon budget for session
        """
        self.complexity_score = complexity_score
        self.accuracy_requirement = accuracy_requirement
        self.token_count = min(token_count / 200.0, 1.0)  # Normalize
        self.task_type = task_type_encoded
        self.carbon_intensity = carbon_intensity / 1000.0  # Normalize
        self.carbon_used_ratio = min(session_carbon_used / session_carbon_budget, 1.0)
    
    def to_array(self) -> np.ndarray:
        """Convert state to numpy array for neural network"""
        return np.array([
            self.complexity_score,
            self.accuracy_requirement / 2.0,  # Normalize to 0-1
            self.token_count,
            self.task_type / 5.0,  # Normalize to 0-1
            self.carbon_intensity,
            self.carbon_used_ratio
        ], dtype=np.float32)
    
    @staticmethod
    def get_state_size() -> int:
        """Get dimension of state vector"""
        return 6


class DQNNetwork(nn.Module):
    """Deep Q-Network for action-value approximation"""
    
    def __init__(self, state_size: int, action_size: int, hidden_sizes: List[int] = [128, 64]):
        super(DQNNetwork, self).__init__()
        
        layers = []
        prev_size = state_size
        
        for hidden_size in hidden_sizes:
            layers.append(nn.Linear(prev_size, hidden_size))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.2))
            prev_size = hidden_size
        
        layers.append(nn.Linear(prev_size, action_size))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, state):
        return self.network(state)


class ReplayBuffer:
    """Experience replay buffer for stable learning"""
    
    def __init__(self, capacity: int = 10000):
        self.buffer = deque(maxlen=capacity)
    
    def add(self, experience: Experience):
        self.buffer.append(experience)
    
    def sample(self, batch_size: int) -> List[Experience]:
        return random.sample(self.buffer, min(batch_size, len(self.buffer)))
    
    def size(self) -> int:
        return len(self.buffer)


class RLRouter:
    """
    Reinforcement Learning based router for green AI orchestration
    Uses DQN to learn optimal model selection policy
    """
    
    def __init__(self, num_models: int = 3, 
                 lambda_energy: float = 0.5,
                 device: str = 'cpu',
                 learning_rate: float = 0.001,
                 gamma: float = 0.95,
                 epsilon_start: float = 1.0,
                 epsilon_end: float = 0.01,
                 epsilon_decay: float = 0.995):
        """
        Args:
            num_models: number of available models (actions)
            lambda_energy: weight for energy in reward (0-1, higher = more weight on energy)
            device: 'cpu' or 'cuda'
            learning_rate: learning rate for optimizer
            gamma: discount factor
            epsilon_start/end/decay: epsilon-greedy exploration parameters
        """
        self.num_models = num_models
        self.lambda_energy = lambda_energy
        self.device = device
        self.gamma = gamma
        self.epsilon = epsilon_start
        self.epsilon_end = epsilon_end
        self.epsilon_decay = epsilon_decay
        
        # Model names mapping
        self.model_names = ['small', 'medium', 'large'][:num_models]
        
        # Task type encoding
        self.task_types = {
            'general': 0, 'coding': 1, 'reasoning': 2,
            'creative': 3, 'factual': 4, 'mathematical': 5
        }
        
        # State and action space
        self.state_size = RLState.get_state_size()
        self.action_size = num_models
        
        # Q-Networks (DQN with target network)
        self.policy_net = DQNNetwork(self.state_size, self.action_size).to(device)
        self.target_net = DQNNetwork(self.state_size, self.action_size).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()
        
        # Optimizer
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=learning_rate)
        self.loss_fn = nn.MSELoss()
        
        # Replay buffer
        self.replay_buffer = ReplayBuffer(capacity=10000)
        
        # Training statistics
        self.training_stats = {
            'episodes': 0,
            'total_reward': 0,
            'avg_reward': 0,
            'epsilon': self.epsilon,
            'losses': []
        }
    
    def select_action(self, state: RLState, training: bool = True) -> int:
        """
        Select action using epsilon-greedy policy
        
        Args:
            state: current state
            training: if True, use exploration; if False, use exploitation only
        
        Returns:
            action (model index)
        """
        # Exploration vs Exploitation
        if training and random.random() < self.epsilon:
            return random.randint(0, self.action_size - 1)
        
        # Exploitation: choose best action according to Q-network
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state.to_array()).unsqueeze(0).to(self.device)
            q_values = self.policy_net(state_tensor)
            action = q_values.argmax(dim=1).item()
        
        return action
    
    def calculate_reward(self, accuracy: float, energy: float, 
                        carbon_budget_exceeded: bool = False) -> float:
        """
        Calculate reward based on accuracy and energy
        
        reward = accuracy - λ * normalized_energy - penalty
        
        Args:
            accuracy: 0-1 accuracy score
            energy: energy consumed in joules
            carbon_budget_exceeded: whether carbon budget was exceeded
        
        Returns:
            reward value
        """
        # Normalize energy (assuming max ~1000 J for large models)
        normalized_energy = min(energy / 1000.0, 1.0)
        
        # Base reward
        reward = accuracy - (self.lambda_energy * normalized_energy)
        
        # Penalty for exceeding carbon budget
        if carbon_budget_exceeded:
            reward -= 0.5
        
        return reward
    
    def store_experience(self, state: RLState, action: int, reward: float,
                        next_state: RLState, done: bool = False):
        """Store experience in replay buffer"""
        experience = Experience(
            state=state.to_array(),
            action=action,
            reward=reward,
            next_state=next_state.to_array(),
            done=done
        )
        self.replay_buffer.add(experience)
    
    def train_step(self, batch_size: int = 32) -> Optional[float]:
        """
        Perform one training step using experience replay
        
        Returns:
            loss value or None if not enough samples
        """
        if self.replay_buffer.size() < batch_size:
            return None
        
        # Sample batch
        batch = self.replay_buffer.sample(batch_size)
        
        # Prepare tensors
        states = torch.FloatTensor([e.state for e in batch]).to(self.device)
        actions = torch.LongTensor([e.action for e in batch]).unsqueeze(1).to(self.device)
        rewards = torch.FloatTensor([e.reward for e in batch]).to(self.device)
        next_states = torch.FloatTensor([e.next_state for e in batch]).to(self.device)
        dones = torch.FloatTensor([e.done for e in batch]).to(self.device)
        
        # Current Q values
        current_q = self.policy_net(states).gather(1, actions).squeeze(1)
        
        # Target Q values
        with torch.no_grad():
            next_q = self.target_net(next_states).max(1)[0]
            target_q = rewards + (self.gamma * next_q * (1 - dones))
        
        # Compute loss
        loss = self.loss_fn(current_q, target_q)
        
        # Optimize
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), 1.0)
        self.optimizer.step()
        
        # Update statistics
        self.training_stats['losses'].append(loss.item())
        
        return loss.item()
    
    def update_target_network(self):
        """Copy weights from policy network to target network"""
        self.target_net.load_state_dict(self.policy_net.state_dict())
    
    def decay_epsilon(self):
        """Decay exploration rate"""
        self.epsilon = max(self.epsilon_end, self.epsilon * self.epsilon_decay)
        self.training_stats['epsilon'] = self.epsilon
    
    def route(self, complexity_score: float, accuracy_requirement: str,
             token_count: int, task_type: str,
             carbon_intensity: float = 400.0,
             session_carbon_used: float = 0.0,
             session_carbon_budget: float = 100.0,
             training: bool = False) -> Dict[str, any]:
        """
        Route request to appropriate model
        
        Returns:
            dict with model_index, model_name, and q_values
        """
        # Encode inputs
        accuracy_req_encoded = {'low': 0, 'medium': 1, 'high': 2}[accuracy_requirement]
        task_type_encoded = self.task_types.get(task_type, 0)
        
        # Create state
        state = RLState(
            complexity_score=complexity_score,
            accuracy_requirement=accuracy_req_encoded,
            token_count=token_count,
            task_type_encoded=task_type_encoded,
            carbon_intensity=carbon_intensity,
            session_carbon_used=session_carbon_used,
            session_carbon_budget=session_carbon_budget
        )
        
        # Select action
        action = self.select_action(state, training=training)
        
        # Get Q-values for analysis
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state.to_array()).unsqueeze(0).to(self.device)
            q_values = self.policy_net(state_tensor).squeeze(0).cpu().numpy()
        
        return {
            'model_index': action,
            'model_name': self.model_names[action],
            'q_values': q_values.tolist(),
            'state': state,
            'epsilon': self.epsilon if training else 0.0
        }
    
    def save_model(self, path: str):
        """Save model weights and training stats"""
        checkpoint = {
            'policy_net': self.policy_net.state_dict(),
            'target_net': self.target_net.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'training_stats': self.training_stats,
            'epsilon': self.epsilon
        }
        torch.save(checkpoint, path)
    
    def load_model(self, path: str):
        """Load model weights and training stats"""
        checkpoint = torch.load(path, map_location=self.device)
        self.policy_net.load_state_dict(checkpoint['policy_net'])
        self.target_net.load_state_dict(checkpoint['target_net'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])
        self.training_stats = checkpoint['training_stats']
        self.epsilon = checkpoint.get('epsilon', self.epsilon_end)


if __name__ == "__main__":
    # Example usage
    router = RLRouter(num_models=3, lambda_energy=0.5)
    
    # Example routing decision
    result = router.route(
        complexity_score=0.7,
        accuracy_requirement='high',
        token_count=100,
        task_type='coding',
        carbon_intensity=450.0,
        session_carbon_used=20.0,
        session_carbon_budget=100.0
    )
    
    print(f"Routed to: {result['model_name']}")
    print(f"Q-values: {result['q_values']}")
    print(f"Epsilon: {result['epsilon']:.3f}")
