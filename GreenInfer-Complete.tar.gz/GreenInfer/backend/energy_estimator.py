"""
Energy and Carbon Estimation Module
Provides both proxy-based and historical benchmark estimation for model routing
"""

import json
import time
from typing import Dict, Optional, List
from dataclasses import dataclass, asdict
from datetime import datetime
import numpy as np
from codecarbon import EmissionsTracker
import requests

@dataclass
class EnergyMetrics:
    """Data class for energy and carbon metrics"""
    model_name: str
    energy_joules: float
    carbon_grams: float
    duration_seconds: float
    token_count: int
    timestamp: str
    task_type: str
    complexity_score: float
    
    def to_dict(self):
        return asdict(self)


class EnergyEstimator:
    """
    Estimates energy consumption and CO2 emissions for AI model inference
    Uses both proxy calculations and historical benchmarks
    """
    
    def __init__(self, history_file='data/energy_history.json'):
        self.history_file = history_file
        self.history = self._load_history()
        
        # Model parameters database (FLOPs per token estimates)
        # These are approximate values from research papers
        self.model_specs = {
            'small': {
                'params': 125_000_000,  # 125M parameters
                'flops_per_token': 2.5e9,  # 2.5 billion FLOPs per token
                'avg_power_watts': 15,  # Typical CPU power
            },
            'medium': {
                'params': 2_700_000_000,  # 2.7B parameters
                'flops_per_token': 5.4e10,  # 54 billion FLOPs per token
                'avg_power_watts': 150,  # Typical GPU power
            },
            'large': {
                'params': 175_000_000_000,  # 175B parameters (GPT-3 size)
                'flops_per_token': 3.5e11,  # 350 billion FLOPs per token
                'avg_power_watts': 400,  # High-end GPU power
            }
        }
        
        # Carbon intensity (grams CO2 per kWh)
        # Default value, can be updated with real-time data
        self.carbon_intensity = 400  # Global average
    
    def _load_history(self) -> List[Dict]:
        """Load historical energy measurements"""
        try:
            with open(self.history_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return []
    
    def _save_history(self):
        """Save historical measurements"""
        with open(self.history_file, 'w') as f:
            json.dump(self.history, f, indent=2)
    
    def proxy_estimate(self, model_size: str, token_count: int, 
                      complexity_score: float = 0.5) -> Dict[str, float]:
        """
        Estimate energy using proxy calculation
        
        Args:
            model_size: 'small', 'medium', or 'large'
            token_count: number of tokens in query
            complexity_score: task complexity (0-1)
        
        Returns:
            dict with energy_joules and carbon_grams
        """
        if model_size not in self.model_specs:
            raise ValueError(f"Unknown model size: {model_size}")
        
        spec = self.model_specs[model_size]
        
        # Base computation time estimate
        # More complex tasks take longer per token
        complexity_multiplier = 1 + (complexity_score * 0.5)
        
        # Estimate inference time (simplified model)
        # time = (FLOPs * tokens) / (hardware FLOPS)
        # Assuming ~10 TFLOPS for GPU, ~0.1 TFLOPS for CPU
        hardware_flops = 10e12 if model_size != 'small' else 0.1e12
        
        estimated_time = (spec['flops_per_token'] * token_count * complexity_multiplier) / hardware_flops
        
        # Energy = Power * Time
        energy_joules = spec['avg_power_watts'] * estimated_time
        
        # Carbon = Energy * Carbon Intensity
        energy_kwh = energy_joules / 3_600_000  # Convert J to kWh
        carbon_grams = energy_kwh * self.carbon_intensity
        
        return {
            'energy_joules': energy_joules,
            'carbon_grams': carbon_grams,
            'estimated_time_seconds': estimated_time,
            'method': 'proxy'
        }
    
    def historical_estimate(self, model_name: str, task_type: str, 
                          token_count: int) -> Optional[Dict[str, float]]:
        """
        Estimate based on historical measurements
        
        Returns average from similar past queries, or None if no history
        """
        # Filter relevant history
        relevant = [
            h for h in self.history
            if h['model_name'] == model_name 
            and h['task_type'] == task_type
            and abs(h['token_count'] - token_count) < 50  # Similar token count
        ]
        
        if not relevant:
            return None
        
        # Calculate averages
        avg_energy = np.mean([h['energy_joules'] for h in relevant])
        avg_carbon = np.mean([h['carbon_grams'] for h in relevant])
        avg_duration = np.mean([h['duration_seconds'] for h in relevant])
        
        return {
            'energy_joules': avg_energy,
            'carbon_grams': avg_carbon,
            'estimated_time_seconds': avg_duration,
            'method': 'historical',
            'sample_size': len(relevant)
        }
    
    def estimate(self, model_name: str, model_size: str, token_count: int,
                task_type: str = 'general', complexity_score: float = 0.5) -> Dict[str, float]:
        """
        Get best available energy estimate
        Prefers historical data if available, falls back to proxy
        """
        # Try historical first
        historical = self.historical_estimate(model_name, task_type, token_count)
        
        if historical and historical['sample_size'] >= 3:
            # We have good historical data
            return historical
        
        # Fall back to proxy estimate
        proxy = self.proxy_estimate(model_size, token_count, complexity_score)
        proxy['model_name'] = model_name
        
        return proxy
    
    def measure_actual(self, model_name: str, model_size: str, 
                      inference_function, token_count: int,
                      task_type: str = 'general', 
                      complexity_score: float = 0.5) -> EnergyMetrics:
        """
        Measure actual energy consumption during inference
        
        Args:
            model_name: identifier for the model
            model_size: 'small', 'medium', or 'large'
            inference_function: callable that runs the model
            token_count: number of tokens in query
            task_type: type of task
            complexity_score: complexity rating
        
        Returns:
            EnergyMetrics object with actual measurements
        """
        tracker = EmissionsTracker(
            project_name=f"green-ai-{model_name}",
            output_dir="data/emissions",
            log_level="error",
            save_to_file=False
        )
        
        tracker.start()
        start_time = time.time()
        
        # Run inference
        try:
            result = inference_function()
        except Exception as e:
            tracker.stop()
            raise e
        
        duration = time.time() - start_time
        emissions = tracker.stop()
        
        # CodeCarbon returns kg, convert to grams
        carbon_grams = emissions * 1000 if emissions else 0
        
        # Estimate energy from duration and model size
        spec = self.model_specs[model_size]
        energy_joules = spec['avg_power_watts'] * duration
        
        metrics = EnergyMetrics(
            model_name=model_name,
            energy_joules=energy_joules,
            carbon_grams=carbon_grams,
            duration_seconds=duration,
            token_count=token_count,
            timestamp=datetime.now().isoformat(),
            task_type=task_type,
            complexity_score=complexity_score
        )
        
        # Add to history
        self.history.append(metrics.to_dict())
        self._save_history()
        
        return metrics
    
    def get_carbon_intensity(self, region: str = 'US-TX') -> float:
        """
        Get real-time carbon intensity for grid-aware routing
        
        Args:
            region: grid region code (e.g., 'US-TX' for Texas)
        
        Returns:
            carbon intensity in grams CO2 per kWh
        """
        try:
            # Try to get real-time data from ElectricityMap
            # Note: This requires an API key in production
            # For now, return regional averages
            
            regional_averages = {
                'US-TX': 450,  # Texas (fossil-heavy)
                'US-CA': 250,  # California (more renewable)
                'US-NY': 300,  # New York
                'US': 400,     # US average
                'EU': 300,     # Europe average
                'global': 475  # Global average
            }
            
            intensity = regional_averages.get(region, regional_averages['global'])
            self.carbon_intensity = intensity
            
            return intensity
            
        except Exception as e:
            print(f"Could not fetch real-time carbon intensity: {e}")
            return self.carbon_intensity
    
    def compare_models(self, models: List[Dict], token_count: int,
                      task_type: str = 'general', 
                      complexity_score: float = 0.5) -> List[Dict]:
        """
        Compare energy estimates for multiple models
        
        Args:
            models: list of dicts with 'name' and 'size' keys
            token_count: number of tokens
            task_type: type of task
            complexity_score: complexity rating
        
        Returns:
            list of models with estimates, sorted by energy efficiency
        """
        results = []
        
        for model in models:
            estimate = self.estimate(
                model_name=model['name'],
                model_size=model['size'],
                token_count=token_count,
                task_type=task_type,
                complexity_score=complexity_score
            )
            
            results.append({
                'model_name': model['name'],
                'model_size': model['size'],
                'energy_joules': estimate['energy_joules'],
                'carbon_grams': estimate['carbon_grams'],
                'estimated_time': estimate['estimated_time_seconds'],
                'method': estimate['method']
            })
        
        # Sort by energy efficiency
        results.sort(key=lambda x: x['energy_joules'])
        
        return results
    
    def calculate_savings(self, baseline_model: str, chosen_model: str,
                         baseline_energy: float, chosen_energy: float) -> Dict:
        """Calculate energy and carbon savings"""
        energy_saved = baseline_energy - chosen_energy
        energy_saved_percent = (energy_saved / baseline_energy) * 100
        
        # Estimate carbon saved based on energy
        carbon_saved = (energy_saved / 3_600_000) * self.carbon_intensity
        
        return {
            'baseline_model': baseline_model,
            'chosen_model': chosen_model,
            'energy_saved_joules': energy_saved,
            'energy_saved_percent': energy_saved_percent,
            'carbon_saved_grams': carbon_saved,
            'baseline_energy': baseline_energy,
            'chosen_energy': chosen_energy
        }


if __name__ == "__main__":
    # Example usage
    estimator = EnergyEstimator()
    
    # Proxy estimate
    result = estimator.proxy_estimate('medium', token_count=50, complexity_score=0.7)
    print(f"Proxy Estimate:")
    print(f"  Energy: {result['energy_joules']:.2f} J")
    print(f"  Carbon: {result['carbon_grams']:.4f} g CO2")
    print(f"  Time: {result['estimated_time_seconds']:.3f} s")
    
    # Compare models
    models = [
        {'name': 'tiny-llama', 'size': 'small'},
        {'name': 'mistral-7b', 'size': 'medium'},
        {'name': 'gpt-4', 'size': 'large'}
    ]
    
    comparison = estimator.compare_models(models, token_count=100, complexity_score=0.6)
    print("\nModel Comparison:")
    for model in comparison:
        print(f"  {model['model_name']}: {model['energy_joules']:.2f} J, {model['carbon_grams']:.4f} g CO2")
