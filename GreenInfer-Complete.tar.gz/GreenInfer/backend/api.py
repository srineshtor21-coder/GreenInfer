"""
Flask Backend API for Green AI Orchestrator
RESTful API for web interface
"""

from flask import Flask, request, jsonify, session
from flask_cors import CORS
import os
import sys
import uuid
from datetime import datetime
import json

# Add backend to path
sys.path.append(os.path.dirname(__file__))

from orchestrator import GreenAIOrchestrator, OrchestratorConfig
from model_registry import ModelRegistry

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
CORS(app, supports_credentials=True)

# Initialize orchestrator
orchestrator = GreenAIOrchestrator()

# Store active sessions
active_sessions = {}


@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    })


@app.route('/api/session/create', methods=['POST'])
def create_session():
    """Create a new user session"""
    session_id = str(uuid.uuid4())
    user_session = orchestrator.create_session(session_id)
    
    active_sessions[session_id] = {
        'created_at': user_session.created_at,
        'mode': orchestrator.config.mode
    }
    
    return jsonify({
        'session_id': session_id,
        'mode': orchestrator.config.mode,
        'carbon_budget': orchestrator.config.session_carbon_budget,
        'energy_budget': orchestrator.config.session_energy_budget
    })


@app.route('/api/session/<session_id>/status', methods=['GET'])
def session_status(session_id):
    """Get current session status"""
    user_session = orchestrator.get_session(session_id)
    
    if not user_session:
        return jsonify({'error': 'Session not found'}), 404
    
    return jsonify({
        'session_id': session_id,
        'carbon_used': user_session.carbon_used,
        'carbon_remaining': orchestrator.config.session_carbon_budget - user_session.carbon_used,
        'carbon_budget': orchestrator.config.session_carbon_budget,
        'energy_used': user_session.energy_used,
        'energy_remaining': orchestrator.config.session_energy_budget - user_session.energy_used,
        'energy_budget': orchestrator.config.session_energy_budget,
        'queries_processed': user_session.queries_processed,
        'mode': orchestrator.config.mode
    })


@app.route('/api/query', methods=['POST'])
def process_query():
    """
    Process a user query through the green orchestrator
    
    Request body:
        {
            "prompt": "user query",
            "session_id": "session_id",
            "mode": "eco|balanced|performance" (optional)
        }
    """
    data = request.json
    
    if not data or 'prompt' not in data:
        return jsonify({'error': 'Missing prompt in request'}), 400
    
    prompt = data['prompt']
    session_id = data.get('session_id')
    mode = data.get('mode')
    
    # Create session if not provided
    if not session_id:
        session_id = str(uuid.uuid4())
        orchestrator.create_session(session_id)
    
    # Update mode if provided
    if mode and mode in ['eco', 'balanced', 'performance']:
        orchestrator.set_mode(mode)
    
    try:
        # Execute query through orchestrator
        result = orchestrator.execute_query(prompt, session_id)
        
        # Add session info
        user_session = orchestrator.get_session(session_id)
        result['session_info'] = {
            'session_id': session_id,
            'carbon_used': user_session.carbon_used,
            'carbon_remaining': orchestrator.config.session_carbon_budget - user_session.carbon_used,
            'energy_used': user_session.energy_used,
            'queries_processed': user_session.queries_processed
        }
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            'error': str(e),
            'session_id': session_id
        }), 500


@app.route('/api/settings/mode', methods=['POST'])
def update_mode():
    """
    Update orchestrator mode
    
    Request body:
        {
            "mode": "eco|balanced|performance"
        }
    """
    data = request.json
    
    if not data or 'mode' not in data:
        return jsonify({'error': 'Missing mode in request'}), 400
    
    mode = data['mode']
    
    if mode not in ['eco', 'balanced', 'performance']:
        return jsonify({'error': 'Invalid mode. Choose: eco, balanced, performance'}), 400
    
    orchestrator.set_mode(mode)
    
    return jsonify({
        'mode': mode,
        'carbon_budget': orchestrator.config.carbon_budget_per_query,
        'energy_budget': orchestrator.config.energy_budget_per_query,
        'min_accuracy': orchestrator.config.min_accuracy_threshold
    })


@app.route('/api/settings/custom', methods=['POST'])
def update_custom_settings():
    """
    Update custom carbon/energy budgets
    
    Request body:
        {
            "carbon_budget": float (grams per query),
            "energy_budget": float (joules per query)
        }
    """
    data = request.json
    
    if 'carbon_budget' in data:
        orchestrator.config.carbon_budget_per_query = float(data['carbon_budget'])
    
    if 'energy_budget' in data:
        orchestrator.config.energy_budget_per_query = float(data['energy_budget'])
    
    orchestrator.config.mode = 'custom'
    
    return jsonify({
        'mode': 'custom',
        'carbon_budget': orchestrator.config.carbon_budget_per_query,
        'energy_budget': orchestrator.config.energy_budget_per_query
    })


@app.route('/api/models/list', methods=['GET'])
def list_models():
    """Get list of available models"""
    models = orchestrator.model_registry.list_models(active_only=True)
    return jsonify({
        'models': models,
        'count': len(models)
    })


@app.route('/api/models/<model_id>', methods=['GET'])
def get_model_info(model_id):
    """Get detailed info about a specific model"""
    model = orchestrator.model_registry.get_model(model_id)
    
    if not model:
        return jsonify({'error': 'Model not found'}), 404
    
    return jsonify(model.to_dict())


@app.route('/api/models/<model_id>/toggle', methods=['POST'])
def toggle_model(model_id):
    """Activate or deactivate a model"""
    data = request.json
    active = data.get('active', True)
    
    if active:
        success = orchestrator.model_registry.activate_model(model_id)
    else:
        success = orchestrator.model_registry.deactivate_model(model_id)
    
    if not success:
        return jsonify({'error': 'Model not found'}), 404
    
    return jsonify({
        'model_id': model_id,
        'active': active
    })


@app.route('/api/analytics/decisions', methods=['GET'])
def get_decision_analytics():
    """Get analytics on routing decisions"""
    decisions = orchestrator.decision_log
    
    if not decisions:
        return jsonify({
            'total_decisions': 0,
            'by_model': {},
            'by_method': {},
            'avg_energy': 0,
            'avg_carbon': 0,
            'total_energy_saved': 0
        })
    
    # Calculate statistics
    total_decisions = len(decisions)
    
    by_model = {}
    by_method = {}
    total_energy = 0
    total_carbon = 0
    
    for decision in decisions:
        d = decision['decision']
        
        # Count by model
        model_name = d['model_name']
        by_model[model_name] = by_model.get(model_name, 0) + 1
        
        # Count by method
        method = d['decision_method']
        by_method[method] = by_method.get(method, 0) + 1
        
        # Sum energy and carbon
        total_energy += d['estimated_energy_joules']
        total_carbon += d['estimated_carbon_grams']
    
    return jsonify({
        'total_decisions': total_decisions,
        'by_model': by_model,
        'by_method': by_method,
        'avg_energy': total_energy / total_decisions,
        'avg_carbon': total_carbon / total_decisions,
        'total_energy': total_energy,
        'total_carbon': total_carbon
    })


@app.route('/api/analytics/savings', methods=['GET'])
def get_savings_analytics():
    """Calculate total environmental savings"""
    decisions = orchestrator.decision_log
    
    if not decisions:
        return jsonify({
            'total_energy_saved': 0,
            'total_carbon_saved': 0,
            'savings_percentage': 0
        })
    
    # Get largest model for baseline
    large_models = orchestrator.model_registry.get_models_by_size('large')
    if not large_models:
        return jsonify({
            'error': 'No large model for baseline comparison'
        }), 400
    
    baseline_model = large_models[0]
    
    total_baseline_energy = 0
    total_actual_energy = 0
    total_baseline_carbon = 0
    total_actual_carbon = 0
    
    for decision in decisions:
        d = decision['decision']
        
        # Actual energy/carbon used
        actual_energy = d['estimated_energy_joules']
        actual_carbon = d['estimated_carbon_grams']
        
        # Baseline (if we had used large model)
        baseline_energy = baseline_model.avg_energy_joules
        baseline_carbon = baseline_model.avg_carbon_grams
        
        total_baseline_energy += baseline_energy
        total_actual_energy += actual_energy
        total_baseline_carbon += baseline_carbon
        total_actual_carbon += actual_carbon
    
    energy_saved = total_baseline_energy - total_actual_energy
    carbon_saved = total_baseline_carbon - total_actual_carbon
    savings_percentage = (energy_saved / total_baseline_energy * 100) if total_baseline_energy > 0 else 0
    
    return jsonify({
        'total_energy_saved': energy_saved,
        'total_carbon_saved': carbon_saved,
        'savings_percentage': savings_percentage,
        'baseline_energy': total_baseline_energy,
        'actual_energy': total_actual_energy,
        'baseline_carbon': total_baseline_carbon,
        'actual_carbon': total_actual_carbon,
        'queries_analyzed': len(decisions)
    })


@app.route('/api/carbon/intensity', methods=['GET'])
def get_carbon_intensity():
    """Get current grid carbon intensity"""
    region = request.args.get('region', 'US-TX')
    intensity = orchestrator.energy_estimator.get_carbon_intensity(region)
    
    return jsonify({
        'region': region,
        'carbon_intensity_g_per_kwh': intensity,
        'timestamp': datetime.now().isoformat()
    })


@app.route('/api/export/metrics', methods=['GET'])
def export_metrics():
    """Export all metrics as JSON"""
    export_path = 'data/metrics_export.json'
    orchestrator.export_metrics(export_path)
    
    with open(export_path, 'r') as f:
        metrics = json.load(f)
    
    return jsonify(metrics)


if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('data', exist_ok=True)
    os.makedirs('data/emissions', exist_ok=True)
    os.makedirs('configs', exist_ok=True)
    os.makedirs('models', exist_ok=True)
    
    # Run Flask app
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )
