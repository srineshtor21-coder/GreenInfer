"""
Model Registry
Dynamic registry for managing AI models in a model-agnostic way
Supports adding/removing models without hardcoding
"""

import json
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, asdict
import os
from datetime import datetime

@dataclass
class ModelConfig:
    """Configuration for a registered model"""
    model_id: str
    model_name: str
    model_size: str  # 'small', 'medium', 'large'
    access_method: str  # 'local', 'api', 'huggingface'
    endpoint: Optional[str]  # API endpoint or HuggingFace model ID
    api_key_env: Optional[str]  # Environment variable for API key
    max_tokens: int
    cost_per_1k_tokens: float  # Cost in USD
    avg_energy_joules: float  # Average energy per query
    avg_carbon_grams: float  # Average carbon per query
    accuracy_profile: Dict[str, float]  # Accuracy scores by task type
    is_active: bool
    created_at: str
    benchmarked: bool
    
    def to_dict(self):
        return asdict(self)


class ModelRegistry:
    """
    Dynamic registry for AI models
    Enables model-agnostic orchestration framework
    """
    
    def __init__(self, registry_file: str = 'configs/model_registry.json'):
        self.registry_file = registry_file
        self.models = self._load_registry()
        self.model_functions = {}  # Storage for inference functions
    
    def _load_registry(self) -> Dict[str, ModelConfig]:
        """Load model registry from file"""
        if not os.path.exists(self.registry_file):
            # Create default registry with example models
            return self._create_default_registry()
        
        try:
            with open(self.registry_file, 'r') as f:
                data = json.load(f)
                return {
                    model_id: ModelConfig(**config)
                    for model_id, config in data.items()
                }
        except Exception as e:
            print(f"Error loading registry: {e}")
            return {}
    
    def _save_registry(self):
        """Save registry to file"""
        os.makedirs(os.path.dirname(self.registry_file), exist_ok=True)
        
        data = {
            model_id: config.to_dict()
            for model_id, config in self.models.items()
        }
        
        with open(self.registry_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def _create_default_registry(self) -> Dict[str, ModelConfig]:
        """Create default registry with common models"""
        defaults = {
            'tinyllama': ModelConfig(
                model_id='tinyllama',
                model_name='TinyLlama-1.1B',
                model_size='small',
                access_method='huggingface',
                endpoint='TinyLlama/TinyLlama-1.1B-Chat-v1.0',
                api_key_env=None,
                max_tokens=2048,
                cost_per_1k_tokens=0.0,
                avg_energy_joules=50.0,
                avg_carbon_grams=0.02,
                accuracy_profile={
                    'general': 0.6,
                    'coding': 0.5,
                    'reasoning': 0.55,
                    'creative': 0.65,
                    'factual': 0.7
                },
                is_active=True,
                created_at=datetime.now().isoformat(),
                benchmarked=False
            ),
            'mistral-7b': ModelConfig(
                model_id='mistral-7b',
                model_name='Mistral-7B',
                model_size='medium',
                access_method='huggingface',
                endpoint='mistralai/Mistral-7B-Instruct-v0.2',
                api_key_env='HUGGINGFACE_API_KEY',
                max_tokens=4096,
                cost_per_1k_tokens=0.0002,
                avg_energy_joules=300.0,
                avg_carbon_grams=0.12,
                accuracy_profile={
                    'general': 0.8,
                    'coding': 0.75,
                    'reasoning': 0.8,
                    'creative': 0.8,
                    'factual': 0.85
                },
                is_active=True,
                created_at=datetime.now().isoformat(),
                benchmarked=False
            ),
            'gpt-4': ModelConfig(
                model_id='gpt-4',
                model_name='GPT-4',
                model_size='large',
                access_method='api',
                endpoint='https://api.openai.com/v1/chat/completions',
                api_key_env='OPENAI_API_KEY',
                max_tokens=8192,
                cost_per_1k_tokens=0.03,
                avg_energy_joules=1000.0,
                avg_carbon_grams=0.4,
                accuracy_profile={
                    'general': 0.95,
                    'coding': 0.93,
                    'reasoning': 0.95,
                    'creative': 0.92,
                    'factual': 0.96
                },
                is_active=False,  # Disabled by default due to cost
                created_at=datetime.now().isoformat(),
                benchmarked=False
            )
        }
        
        self.models = defaults
        self._save_registry()
        return defaults
    
    def register_model(self, config: ModelConfig) -> bool:
        """
        Register a new model
        
        Args:
            config: ModelConfig object
        
        Returns:
            True if successful, False otherwise
        """
        if config.model_id in self.models:
            print(f"Model {config.model_id} already exists. Use update_model instead.")
            return False
        
        self.models[config.model_id] = config
        self._save_registry()
        print(f"Model {config.model_id} registered successfully.")
        return True
    
    def update_model(self, model_id: str, **kwargs) -> bool:
        """
        Update model configuration
        
        Args:
            model_id: ID of model to update
            **kwargs: fields to update
        
        Returns:
            True if successful, False otherwise
        """
        if model_id not in self.models:
            print(f"Model {model_id} not found.")
            return False
        
        config = self.models[model_id]
        config_dict = asdict(config)
        
        for key, value in kwargs.items():
            if key in config_dict:
                setattr(config, key, value)
        
        self._save_registry()
        print(f"Model {model_id} updated successfully.")
        return True
    
    def deactivate_model(self, model_id: str):
        """Deactivate a model (keep in registry but don't use)"""
        return self.update_model(model_id, is_active=False)
    
    def activate_model(self, model_id: str):
        """Activate a model"""
        return self.update_model(model_id, is_active=True)
    
    def remove_model(self, model_id: str) -> bool:
        """
        Remove model from registry
        
        Args:
            model_id: ID of model to remove
        
        Returns:
            True if successful, False otherwise
        """
        if model_id not in self.models:
            print(f"Model {model_id} not found.")
            return False
        
        del self.models[model_id]
        self._save_registry()
        print(f"Model {model_id} removed from registry.")
        return True
    
    def get_model(self, model_id: str) -> Optional[ModelConfig]:
        """Get model configuration by ID"""
        return self.models.get(model_id)
    
    def get_active_models(self) -> List[ModelConfig]:
        """Get all active models"""
        return [
            config for config in self.models.values()
            if config.is_active
        ]
    
    def get_models_by_size(self, size: str) -> List[ModelConfig]:
        """Get all active models of a specific size"""
        return [
            config for config in self.models.values()
            if config.is_active and config.model_size == size
        ]
    
    def benchmark_model(self, model_id: str, 
                       benchmark_results: Dict[str, float],
                       energy_joules: float,
                       carbon_grams: float):
        """
        Update model with benchmark results
        
        Args:
            model_id: ID of model to update
            benchmark_results: dict of task_type -> accuracy
            energy_joules: measured average energy
            carbon_grams: measured average carbon
        """
        if model_id not in self.models:
            print(f"Model {model_id} not found.")
            return False
        
        self.update_model(
            model_id,
            accuracy_profile=benchmark_results,
            avg_energy_joules=energy_joules,
            avg_carbon_grams=carbon_grams,
            benchmarked=True
        )
        
        print(f"Model {model_id} benchmarked successfully.")
        return True
    
    def register_inference_function(self, model_id: str, 
                                   inference_fn: Callable):
        """
        Register inference function for a model
        
        Args:
            model_id: ID of model
            inference_fn: callable that takes (prompt, max_tokens) and returns response
        """
        self.model_functions[model_id] = inference_fn
    
    def get_inference_function(self, model_id: str) -> Optional[Callable]:
        """Get registered inference function"""
        return self.model_functions.get(model_id)
    
    def list_models(self, active_only: bool = True) -> List[Dict]:
        """
        List all models with their key information
        
        Args:
            active_only: if True, only return active models
        
        Returns:
            list of model summaries
        """
        models = self.get_active_models() if active_only else self.models.values()
        
        return [
            {
                'model_id': config.model_id,
                'model_name': config.model_name,
                'size': config.model_size,
                'access': config.access_method,
                'energy': config.avg_energy_joules,
                'carbon': config.avg_carbon_grams,
                'benchmarked': config.benchmarked,
                'active': config.is_active
            }
            for config in models
        ]
    
    def get_routing_candidates(self, max_energy: Optional[float] = None,
                              max_carbon: Optional[float] = None,
                              min_accuracy: Optional[float] = None,
                              task_type: str = 'general') -> List[ModelConfig]:
        """
        Get models that meet specified constraints
        
        Args:
            max_energy: maximum energy budget in joules
            max_carbon: maximum carbon budget in grams
            min_accuracy: minimum required accuracy for task type
            task_type: type of task
        
        Returns:
            list of suitable models, sorted by efficiency
        """
        candidates = []
        
        for config in self.get_active_models():
            # Check energy constraint
            if max_energy and config.avg_energy_joules > max_energy:
                continue
            
            # Check carbon constraint
            if max_carbon and config.avg_carbon_grams > max_carbon:
                continue
            
            # Check accuracy constraint
            if min_accuracy:
                model_accuracy = config.accuracy_profile.get(task_type, 0.0)
                if model_accuracy < min_accuracy:
                    continue
            
            candidates.append(config)
        
        # Sort by energy efficiency (energy per accuracy point)
        candidates.sort(
            key=lambda c: c.avg_energy_joules / 
                         max(c.accuracy_profile.get(task_type, 0.5), 0.1)
        )
        
        return candidates
    
    def export_registry(self, filepath: str):
        """Export registry to a specific file"""
        data = {
            model_id: config.to_dict()
            for model_id, config in self.models.items()
        }
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def import_registry(self, filepath: str):
        """Import registry from a file"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        for model_id, config_dict in data.items():
            config = ModelConfig(**config_dict)
            if model_id not in self.models:
                self.models[model_id] = config
        
        self._save_registry()


if __name__ == "__main__":
    # Example usage
    registry = ModelRegistry()
    
    # List models
    print("Active Models:")
    for model in registry.list_models():
        print(f"  {model['model_name']} ({model['size']}): "
              f"{model['energy']:.1f}J, {model['carbon']:.3f}g CO2")
    
    # Add custom model
    custom_model = ModelConfig(
        model_id='custom-local',
        model_name='Custom Local Model',
        model_size='small',
        access_method='local',
        endpoint=None,
        api_key_env=None,
        max_tokens=1024,
        cost_per_1k_tokens=0.0,
        avg_energy_joules=30.0,
        avg_carbon_grams=0.015,
        accuracy_profile={'general': 0.55},
        is_active=True,
        created_at=datetime.now().isoformat(),
        benchmarked=False
    )
    
    registry.register_model(custom_model)
    
    # Get routing candidates
    candidates = registry.get_routing_candidates(
        max_energy=500.0,
        min_accuracy=0.7,
        task_type='coding'
    )
    
    print("\nRouting Candidates (energy < 500J, accuracy > 0.7):")
    for model in candidates:
        print(f"  {model.model_name}")
